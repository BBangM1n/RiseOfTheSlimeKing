﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BossUI : MonoBehaviour
{
    public static BossUI Instance { get; private set; }

    [Header("Root")]
    [SerializeField] private GameObject root;

    [Header("UI")]
    [SerializeField] private Slider hpSlider;
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private TextMeshProUGUI hpText;

    [Header("Warp")]
    [SerializeField] private GameObject warp;

    private Enemy currentBoss;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        if (root != null) root.SetActive(false);
        if (warp != null) warp.SetActive(false);

        if (hpSlider != null) hpSlider.gameObject.SetActive(false);
        if (hpText != null) hpText.gameObject.SetActive(false);
        if (nameText != null) nameText.gameObject.SetActive(false);
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;

        UnsubscribeBoss();
    }

    public void ShowBoss(Enemy boss, string displayName)
    {
        UnsubscribeBoss();
        currentBoss = boss;
        SubscribeBoss();

        if (nameText != null) nameText.text = displayName;

        if (hpSlider != null && boss != null)
        {
            hpSlider.maxValue = boss.MaxHP;
            hpSlider.value = boss.CurrentHP;
        }

        SetBossUiVisible(true);

        if (root != null) root.SetActive(true);
    }

    public void HideBoss()
    {
        UnsubscribeBoss();
        currentBoss = null;

        if (root != null) root.SetActive(false);
        if (warp != null) warp.SetActive(true);
    }

    private void SubscribeBoss()
    {
        if (currentBoss != null)
            currentBoss.OnHPChanged += OnBossHpChanged;
    }

    private void UnsubscribeBoss()
    {
        if (currentBoss != null)
            currentBoss.OnHPChanged -= OnBossHpChanged;
    }

    private void SetBossUiVisible(bool visible)
    {
        if (hpSlider != null) hpSlider.gameObject.SetActive(visible);
        if (hpText != null) hpText.gameObject.SetActive(visible);
        if (nameText != null) nameText.gameObject.SetActive(visible);
    }

    private void OnBossHpChanged(float current, float max)
    {
        if (hpSlider == null || hpText == null) return;

        hpSlider.maxValue = max;
        hpSlider.value = current;
        hpText.text = $"{Mathf.CeilToInt(current)} / {Mathf.CeilToInt(max)}";
    }
}
