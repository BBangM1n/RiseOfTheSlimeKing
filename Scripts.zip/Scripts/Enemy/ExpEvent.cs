using System;

public static class ExpEvent
{
    public static Action<int> OnAddExp;
}
