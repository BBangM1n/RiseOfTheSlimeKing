using System.Collections.Generic;
using UnityEngine;

public static class MonsterDatabase
{
    private static Dictionary<string, MonsterData> dict;

    public static void Initialize(List<MonsterData> list)
    {
        dict = new Dictionary<string, MonsterData>();

        foreach (var data in list)
        {
            if (data == null || string.IsNullOrEmpty(data.ID))
                continue;

            if (!dict.ContainsKey(data.ID))
                dict.Add(data.ID, data);
        }

        Debug.Log($"[MonsterDatabase] Initialized: {dict.Count}");
    }

    public static MonsterData Get(string id)
    {
        if (dict == null)
        {
            Debug.LogError("[MonsterDatabase] Not initialized.");
            return null;
        }

        if (!dict.TryGetValue(id, out var data))
        {
            Debug.LogError($"[MonsterDatabase] MonsterData not found: {id}");
            return null;
        }

        return data;
    }
}
