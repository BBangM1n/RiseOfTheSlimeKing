using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

public static class MonsterCSVLoader
{
    public static async UniTask<List<MonsterData>> LoadAddressablesAsync(string addressKey)
    {
        var list = new List<MonsterData>();

        var handle = Addressables.LoadAssetAsync<TextAsset>(addressKey);
        TextAsset csv = await handle.Task;

        if (handle.Status != AsyncOperationStatus.Succeeded || csv == null)
        {
            Debug.LogError($"[MonsterCSVLoader] CSV load failed: {addressKey}");
            Addressables.Release(handle);
            return list;
        }

        Parse(csv.text, list);
        Addressables.Release(handle);

        Debug.Log($"[MonsterCSVLoader] Loaded: {list.Count} monsters");
        return list;
    }

    private static void Parse(string text, List<MonsterData> list)
    {
        string[] lines = text.Split('\n');

        for (int i = 1; i < lines.Length; i++)
        {
            string line = lines[i].Trim();
            if (string.IsNullOrWhiteSpace(line))
                continue;

            string[] v = line.Split(',');

            if (v.Length < 8)
            {
                Debug.LogWarning($"[MonsterCSVLoader] Invalid row (columns < 8): {line}");
                continue;
            }

            int maxHp = ParseIntSafe(v[3], "MaxHP", v[0], line);
            float moveSpeed = ParseFloatSafe(v[4], "MoveSpeed", v[0], line);
            int attack = ParseIntSafe(v[5], "Attack", v[0], line);
            int defense = ParseIntSafe(v[6], "Defense", v[0], line);
            int exp = ParseIntSafe(v[7], "Exp", v[0], line);

            var data = new MonsterData
            {
                ID = v[0].Trim(),
                KR = v[1].Trim(),
                PoolKey = v[2].Trim(),
                MaxHP = maxHp,
                MoveSpeed = moveSpeed,
                Attack = attack,
                Defense = defense,
                Exp = exp
            };

            list.Add(data);
        }
    }

    private static int ParseIntSafe(string s, string field, string id, string line, int defaultValue = 0)
    {
        if (int.TryParse(s.Trim(), out int val))
            return val;

        Debug.LogWarning($"[MonsterCSVLoader] {field} int parse failed. id={id}, value='{s}', line='{line}'");
        return defaultValue;
    }

    private static float ParseFloatSafe(string s, string field, string id, string line, float defaultValue = 0f)
    {
        if (float.TryParse(s.Trim(), out float val))
            return val;

        Debug.LogWarning($"[MonsterCSVLoader] {field} float parse failed. id={id}, value='{s}', line='{line}'");
        return defaultValue;
    }
}
