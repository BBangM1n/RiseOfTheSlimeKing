﻿using UnityEngine;

public class Slime : Enemy
{
    [Header("Move Settings")]
    [SerializeField] private float directionChangeInterval = 2f;
    [SerializeField] private LayerMask wallLayer;
    [SerializeField] private float wallCheckDistance = 0.1f;

    [Header("Visual")]
    [SerializeField] private Transform visualRoot;

    private Vector2 moveDirection;
    private float timer;

    protected override void OnEnable()
    {
        base.OnEnable();
        PickRandomDirection();
        timer = 0f;
    }

    private void Update()
    {
        if (!CanUpdate())
            return;

        Move();
    }

    public override void Move()
    {
        if (moveDirection != Vector2.zero)
        {
            var hit = Physics2D.Raycast(transform.position, moveDirection, wallCheckDistance, wallLayer);
            if (hit.collider != null)
            {
                moveDirection = -moveDirection;
                UpdateFlip();
                return;
            }
        }

        transform.Translate(moveDirection * data.MoveSpeed * Time.deltaTime);

        timer += Time.deltaTime;
        if (timer >= directionChangeInterval)
        {
            PickRandomDirection();
            timer = 0f;
        }
    }

    private void PickRandomDirection()
    {
        moveDirection = Random.Range(0, 3) switch
        {
            0 => Vector2.left,
            1 => Vector2.zero,
            2 => Vector2.right,
            _ => Vector2.zero
        };

        UpdateFlip();
    }

    private void UpdateFlip()
    {
        if (moveDirection.x == 0f)
            return;

        if (visualRoot == null)
            return;

        visualRoot.localScale = new Vector3(Mathf.Sign(moveDirection.x), 1f, 1f);
    }
}
