using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class MonsterPoolManager : MonoBehaviour
{
    [System.Serializable]
    public class PoolData
    {
        public string key;
        public GameObject prefab;
        public int initialSize = 10;
        public int maxSize = 50;
    }

    [SerializeField] private List<PoolData> poolDataList;

    private readonly Dictionary<string, ObjectPool<GameObject>> pools = new();

    private void Awake()
    {
        BuildPools();
    }

    private void OnEnable()
    {
        PoolManager.Instance?.RegisterMonsterPool(this);
    }

    private void OnDisable()
    {
        PoolManager.Instance?.UnregisterMonsterPool(this);
    }

    private void BuildPools()
    {
        pools.Clear();

        if (poolDataList == null || poolDataList.Count == 0)
        {
#if UNITY_EDITOR
            Debug.LogWarning("[MonsterPoolManager] Ǯ �����Ͱ� �������.");
#endif
            return;
        }

        foreach (var data in poolDataList)
        {
            if (data == null)
                continue;

            if (string.IsNullOrWhiteSpace(data.key))
            {
                Debug.LogError("[MonsterPoolManager] Ǯ Ű�� ����.");
                continue;
            }

            if (data.prefab == null)
            {
                Debug.LogError($"[MonsterPoolManager] �������� ����. key={data.key}");
                continue;
            }

            if (pools.ContainsKey(data.key))
            {
                Debug.LogError($"[MonsterPoolManager] Ǯ�� ��������� key: {data.key}");
                continue;
            }

            var localData = data;

            var pool = new ObjectPool<GameObject>(
                () => CreateObject(localData.prefab),
                obj => obj.SetActive(true),
                obj => obj.SetActive(false),
                obj => Destroy(obj),
                collectionCheck: false,
                defaultCapacity: localData.initialSize,
                maxSize: localData.maxSize
            );

            WarmUp(pool, localData.prefab, localData.initialSize);
            pools.Add(localData.key, pool);
        }
    }

    private void WarmUp(ObjectPool<GameObject> pool, GameObject prefab, int count)
    {
        for (int i = 0; i < count; i++)
        {
            var obj = Instantiate(prefab, transform);
            obj.name = $"{prefab.name}_{i}";
            obj.SetActive(false);
            pool.Release(obj);
        }
    }

    private GameObject CreateObject(GameObject prefab)
    {
        var obj = Instantiate(prefab, transform);
        obj.name = $"{prefab.name}_{Random.Range(0, 10000)}";
        obj.SetActive(false);
        return obj;
    }

    public bool HasKey(string key) => pools.ContainsKey(key);

    public GameObject GetObject(string key, Vector3 position, Quaternion rotation)
    {
        if (!pools.TryGetValue(key, out var pool))
        {
            Debug.LogError($"[MonsterPoolManager] Ǯ�̾��� for key: {key}");
            return null;
        }

        var obj = pool.Get();
        obj.transform.SetParent(null);
        obj.transform.SetPositionAndRotation(position, rotation);
        return obj;
    }

    public void ReleaseObject(string key, GameObject obj)
    {
        if (obj == null)
            return;

        if (!pools.TryGetValue(key, out var pool))
        {
#if UNITY_EDITOR
            Debug.LogWarning($"[MonsterPoolManager] Release ���� . Ű�� ���� for key: {key}. ������.");
#endif
            Destroy(obj);
            return;
        }

        obj.transform.SetParent(transform);
        pool.Release(obj);
    }
}
