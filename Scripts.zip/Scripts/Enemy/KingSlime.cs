﻿using System.Collections;
using UnityEngine;

public class KingSlime : Enemy
{
    [Header("Movement")]
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float moveSpeed = 1.5f;

    [Header("Pattern Settings")]
    [SerializeField] private float phase2HPPercent = 0.5f;
    [SerializeField] private float patternInterval = 2.5f;

    [Header("Jump Attack")]
    [SerializeField] private float jumpForce = 8f;

    [Header("Dash Attack")]
    [SerializeField] private float dashSpeed = 10f;
    [SerializeField] private float dashDuration = 0.6f;

    [Header("Minion Spawn")]
    [SerializeField] private string minionMonsterID = "M001";
    [SerializeField] private int minionCount = 3;
    [SerializeField] private float minionSpawnRadius = 2f;

    private Transform player;
    private bool isPhase2;
    private bool isBattleStarted;

    private Coroutine patternCoroutine;

    public override void Initialize(MonsterData monsterData)
    {
        base.Initialize(monsterData);

        if (BossUI.Instance != null && data != null)
            BossUI.Instance.ShowBoss(this, data.KR);

        CachePlayer();

        if (!isBattleStarted)
        {
            isBattleStarted = true;
            patternCoroutine = StartCoroutine(PatternLoop());
        }

        isInitialized = true;
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        isPhase2 = false;
        isBattleStarted = false;
    }

    protected override void OnDisable()
    {
        if (patternCoroutine != null)
        {
            StopCoroutine(patternCoroutine);
            patternCoroutine = null;
        }

        base.OnDisable();
    }

    private void Update()
    {
        if (!CanUpdate())
            return;

        Move();
    }

    public override void Move()
    {
        if (player == null || rb == null)
            return;

        float dirX = Mathf.Sign(player.position.x - transform.position.x);

        Vector2 vel = rb.velocity;
        vel.x = dirX * moveSpeed;
        rb.velocity = vel;

        Vector3 scale = transform.localScale;
        scale.x = dirX > 0 ? Mathf.Abs(scale.x) : -Mathf.Abs(scale.x);
        transform.localScale = scale;
    }

    protected override void Die()
    {
        if (patternCoroutine != null)
        {
            StopCoroutine(patternCoroutine);
            patternCoroutine = null;
        }

        BossUI.Instance?.HideBoss();
        base.Die();
    }

    private void CachePlayer()
    {
        if (player != null)
            return;

        var go = GameObject.FindGameObjectWithTag("Player");
        if (go != null)
            player = go.transform;
    }

    private IEnumerator PatternLoop()
    {
        while (currentHP > 0f)
        {
            if (!isPhase2 && currentHP <= MaxHP * phase2HPPercent)
                EnterPhase2();

            if (!isPhase2)
            {
                yield return JumpAttackPattern();
                yield return new WaitForSeconds(patternInterval);

                yield return DashAttackPattern();
                yield return new WaitForSeconds(patternInterval);
            }
            else
            {
                yield return JumpAttackPattern();
                yield return new WaitForSeconds(patternInterval);

                yield return SpawnMinionPattern();
                yield return new WaitForSeconds(patternInterval);

                yield return DashAttackPattern();
                yield return new WaitForSeconds(patternInterval);
            }
        }
    }

    private void EnterPhase2()
    {
        isPhase2 = true;
        moveSpeed *= 2f;
        dashSpeed *= 1.8f;
    }

    private IEnumerator JumpAttackPattern()
    {
        if (rb == null || player == null)
            yield break;

        rb.velocity = new Vector2(0f, rb.velocity.y);
        AudioManager.Instance?.PlaySfx(SfxType.BossAttack3);
        yield return new WaitForSeconds(0.4f);

        float dirX = Mathf.Sign(player.position.x - transform.position.x);
        rb.velocity = new Vector2(dirX * (moveSpeed * 2f), jumpForce);

        yield return new WaitForSeconds(1.0f);
    }

    private IEnumerator SpawnMinionPattern()
    {
        if (string.IsNullOrEmpty(minionMonsterID))
            yield break;

        for (int i = 0; i < minionCount; i++)
        {
            Vector2 offset = Random.insideUnitCircle * minionSpawnRadius;
            Vector3 spawnPos = transform.position + (Vector3)offset;

            MonsterFactory.Instance.Create(minionMonsterID, spawnPos);
            AudioManager.Instance?.PlaySfx(SfxType.BossAttack1);
            yield return new WaitForSeconds(0.3f);
        }
    }

    private IEnumerator DashAttackPattern()
    {
        if (rb == null || player == null)
            yield break;

        rb.velocity = new Vector2(0f, rb.velocity.y);
        AudioManager.Instance?.PlaySfx(SfxType.BossAttack2);
        yield return new WaitForSeconds(0.4f);

        float dirX = Mathf.Sign(player.position.x - transform.position.x);
        float elapsed = 0f;

        while (elapsed < dashDuration)
        {
            elapsed += Time.deltaTime;
            rb.velocity = new Vector2(dirX * dashSpeed, rb.velocity.y);
            yield return null;
        }

        rb.velocity = new Vector2(0f, rb.velocity.y);
    }
}
