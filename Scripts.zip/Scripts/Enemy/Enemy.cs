﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;

public abstract class Enemy : MonoBehaviour
{
    public event Action<float, float> OnHPChanged;

    [Header("Drop")]
    [SerializeField] private ItemDropper dropper;

    [Header("Damage Text")]
    [SerializeField] private Transform damageTextRoot;
    private const string DamageTextPoolKey = "DamageText";

    [Header("Hit Effect")]
    [SerializeField] private SpriteRenderer spriteRenderer;
    [SerializeField] private TextMeshProUGUI enemyNameText;

    protected string poolKey;
    protected MonsterData data;
    protected float currentHP;
    protected bool isInitialized;

    private Coroutine hitEffectCoroutine;

    public float Damage => data != null ? data.Attack : 0f;
    public float MaxHP => data != null ? data.MaxHP : 0f;
    public float CurrentHP => currentHP;

    public virtual void Initialize(MonsterData monsterData)
    {
        data = monsterData;
        poolKey = data != null ? data.PoolKey : null;

        currentHP = data != null ? data.MaxHP : 0f;
        isInitialized = true;

        if (enemyNameText != null && data != null)
            enemyNameText.text = data.KR;

        OnHPChanged?.Invoke(currentHP, MaxHP);
    }

    protected virtual void OnEnable()
    {
        if (data != null)
        {
            currentHP = data.MaxHP;
            OnHPChanged?.Invoke(currentHP, MaxHP);
        }

        isInitialized = false;
    }

    protected virtual void OnDisable()
    {
        if (hitEffectCoroutine != null)
        {
            StopCoroutine(hitEffectCoroutine);
            hitEffectCoroutine = null;
        }

        if (spriteRenderer != null)
            spriteRenderer.color = Color.white;
    }

    public abstract void Move();

    public virtual void TakeDamage(float damage)
    {
        if (currentHP <= 0f)
            return;

        AudioManager.Instance?.PlaySfx(SfxType.MonsterHit);

        currentHP -= damage;

        ShowDamageText((int)damage);
        PlayHitEffect();
        OnHPChanged?.Invoke(currentHP, MaxHP);

        if (currentHP <= 0f)
            Die();
    }

    public void PlayHitEffect()
    {
        if (spriteRenderer == null)
            return;

        if (hitEffectCoroutine != null)
            StopCoroutine(hitEffectCoroutine);

        hitEffectCoroutine = StartCoroutine(HitEffectRoutine());
    }

    public virtual void Attack() { }

    protected bool CanUpdate()
    {
        return isInitialized && data != null;
    }

    protected virtual void Die()
    {
        OnHPChanged?.Invoke(0f, MaxHP);

        if (data != null)
        {
            LogPupupManager.Instance.AddExp(data.Exp);
            ExpEvent.OnAddExp?.Invoke(data.Exp);

            QuestManager.Instance.CheckObjective("Kill", data.ID);
        }

        dropper?.DropItems();

        if (data != null && !string.IsNullOrEmpty(data.PoolKey) && PoolManager.Instance != null)
            PoolManager.Instance.ReleaseObject(data.PoolKey, gameObject);
        else
            gameObject.SetActive(false);
    }

    private IEnumerator HitEffectRoutine()
    {
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = Color.white;
    }

    private void ShowDamageText(int damage)
    {
        if (damageTextRoot == null) return;
        if (PoolManager.Instance == null) return;
        if (DamageTextManager.Root == null) return;

        GameObject obj = PoolManager.Instance.GetObject(
            DamageTextPoolKey,
            damageTextRoot.position,
            Quaternion.identity
        );

        if (obj == null)
            return;

        obj.transform.SetParent(DamageTextManager.Root, true);

        DamageText dt = obj.GetComponent<DamageText>();
        if (dt == null)
            return;

        dt.Init(DamageTextPoolKey);
        dt.Play(damage, Color.white, 1f);
    }
}
