﻿using UnityEngine;
using UnityEngine.UI;

public class EnemyHealthBar : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Slider hpSlider;
    [SerializeField] private GameObject barVisualRoot;

    private Enemy enemy;
    private bool hasBeenHit;

    private void Awake()
    {
        enemy = GetComponentInParent<Enemy>();
        if (enemy == null)
        {
            Debug.LogError("[EnemyHealthBar] Enemy not found in parent.");
            enabled = false;
            return;
        }
    }

    private void OnEnable()
    {
        enemy.OnHPChanged += OnHpChanged;

        hasBeenHit = false;
        if (barVisualRoot != null) barVisualRoot.SetActive(false);

        UpdateSlider(enemy.CurrentHP, enemy.MaxHP);
    }

    private void OnDisable()
    {
        if (enemy != null)
            enemy.OnHPChanged -= OnHpChanged;

        hasBeenHit = false;
        if (barVisualRoot != null) barVisualRoot.SetActive(false);
    }

    private void OnHpChanged(float current, float max)
    {
        if (!UpdateSlider(current, max))
            return;

        if (!hasBeenHit && current < max)
        {
            hasBeenHit = true;
            if (barVisualRoot != null) barVisualRoot.SetActive(true);
        }
    }

    private bool UpdateSlider(float current, float max)
    {
        if (hpSlider == null) return false;
        if (max <= 0f) return false;

        float t = Mathf.Clamp01(current / max);

        hpSlider.minValue = 0f;
        hpSlider.maxValue = 1f;
        hpSlider.value = t;

        return true;
    }
}
