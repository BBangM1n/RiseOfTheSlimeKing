using System;
using UnityEngine;

[Serializable]
public class MonsterData
{
    public string ID;
    public string KR;
    public string PoolKey;
    public int MaxHP;
    public float MoveSpeed;
    public int Attack;
    public int Defense;
    public int Exp;
}
