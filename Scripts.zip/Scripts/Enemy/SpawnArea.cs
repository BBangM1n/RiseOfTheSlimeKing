﻿using System.Collections.Generic;
using UnityEngine;

public class SpawnArea : MonoBehaviour
{
    [Header("Monster")]
    [SerializeField] private string monsterID = "M001";

    [Header("Spawn Settings")]
    [SerializeField] private int maxCount = 10;
    [SerializeField] private float spawnInterval = 3f;
    [SerializeField] private float spawnRadius = 5f;

    private readonly List<Enemy> spawnedMonsters = new();
    private float timer;

    private void Start()
    {
        TrySpawn();
    }

    private void Update()
    {
        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            timer = 0f;
            TrySpawn();
        }
    }

    private void TrySpawn()
    {
        spawnedMonsters.RemoveAll(m => m == null || !m.gameObject.activeSelf);

        int needCount = maxCount - spawnedMonsters.Count;
        if (needCount <= 0)
            return;

        for (int i = 0; i < needCount; i++)
        {
            SpawnOne();
        }
    }

    private void SpawnOne()
    {
        Vector3 spawnPos = GetRandomPosition();
        Enemy monster = MonsterFactory.Instance.Create(monsterID, spawnPos);

        if (monster != null)
            spawnedMonsters.Add(monster);
    }

    private Vector3 GetRandomPosition()
    {
        float randX = Random.Range(-spawnRadius, spawnRadius);
        return new Vector3(transform.position.x + randX, transform.position.y, transform.position.z);
    }

#if UNITY_EDITOR
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, spawnRadius);
    }
#endif
}
