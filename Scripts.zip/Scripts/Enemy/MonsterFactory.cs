using UnityEngine;

public class MonsterFactory : MonoBehaviour
{
    public static MonsterFactory Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    public Enemy Create(string monsterID, Vector3 position)
    {
        MonsterData data = MonsterDatabase.Get(monsterID);
        if (data == null) return null;

        GameObject obj = PoolManager.Instance.GetObject(
            data.PoolKey,
            position,
            Quaternion.identity
        );

        Enemy enemy = obj.GetComponent<Enemy>();
        enemy.Initialize(data);

        return enemy;
    }
}
