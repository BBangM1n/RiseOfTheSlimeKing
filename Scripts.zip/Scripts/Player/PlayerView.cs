using UnityEngine;

public class PlayerView : MonoBehaviour
{
    public Rigidbody2D rb;
    public Transform groundCheckPoint;
    public float groundCheckDistance = 0.6f;
    public LayerMask groundLayer;
    public ParticleSystem dashParticle;
    public Animator anim;

    public void SetVelocity(Vector2 v) => rb.velocity = v;
    public Vector2 GetVelocity() => rb.velocity;

    public void SetRunning(bool running)
    {
        anim.SetFloat("RunState", running ? 0.5f : 0f);
        anim.SetBool("Run", running);
    }

    public void FlipCharacter(float h)
    {
        if (h > 0) transform.rotation = Quaternion.Euler(0, 180, 0);
        else if (h < 0) transform.rotation = Quaternion.Euler(0, 0, 0);
    }

    public void SetAttack() => anim.SetTrigger("Attack");

    public void SetDeath()
    {
        anim.SetBool("EditChk", false);
        anim.SetTrigger("Die");
    }

    public bool CheckGrounded()
    {
        return Physics2D.Raycast(
            groundCheckPoint.position,
            Vector2.down,
            groundCheckDistance,
            groundLayer
        );
    }

    public void FreezeOnDeath()
    {
        rb.velocity = Vector2.zero;
        rb.angularVelocity = 0f;
        rb.constraints = RigidbodyConstraints2D.FreezeAll;
    }

    public void UnfreezeOnRespawn()
    {
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    public void EnableEdit()
    {
        anim.SetBool("EditChk", true);
        SetRunning(false);
    }
}
