﻿using Cysharp.Threading.Tasks;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    private PlayerModel model;
    private PlayerView view;

    [SerializeField] private HitBox hitBox;

    private float dashTimer;
    private float attackCooldown = 1f;
    private float lastAttackTime = -999f;

    private void Awake()
    {
        model = GetComponent<PlayerModel>();
        view = GetComponent<PlayerView>();
    }

    private void Start()
    {
        SyncUI();
    }

    private void OnEnable()
    {
        model.onLevelUp += SyncUI;
        model.onDie += OnDeath;

        hitBox.Hit += ApplyDamage;
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        model.onLevelUp -= SyncUI;
        model.onDie -= OnDeath;

        hitBox.Hit -= ApplyDamage;
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void Update()
    {
        if (model.IsDead)
            return;

        HandleMove();
        HandleJump();
        HandleGroundCheck();
        HandleDash();
        HandleAttack();
        HandleSkills();
        HandleNPCInteraction();
        HandleInventory();
        HandleConsumable();
        HandleSkillUI();
        HandleMenuUI();
    }

    #region Movement
    private void HandleMove()
    {
        if (model.isDashing) return;

        float input = Input.GetAxisRaw("Horizontal");
        Vector2 velocity = view.GetVelocity();
        velocity.x = input * model.moveSpeed;
        view.SetVelocity(velocity);

        CheckDashInput();

        if (input != 0)
        {
            view.SetRunning(true);
            view.FlipCharacter(input);
        }
        else
        {
            view.SetRunning(false);
        }
    }

    private void HandleJump()
    {
        if (!model.isGrounded) return;
        if (!Input.GetButtonDown("Jump")) return;

        Vector2 velocity = view.GetVelocity();
        velocity.y = model.jumpForce;
        view.SetVelocity(velocity);

        model.SetJumping(true);
        model.SetGrounded(false);
    }

    private void HandleGroundCheck()
    {
        bool grounded = view.CheckGrounded();
        if (grounded && model.isJumping)
            model.SetJumping(false);

        model.SetGrounded(grounded);
    }
    #endregion

    #region Attack / Skill
    private void HandleAttack()
    {
        if (!Input.GetButtonDown("A"))
            return;

        if (Time.time < lastAttackTime + attackCooldown)
            return;

        view.SetAttack();
        hitBox.BasicAttack();
        lastAttackTime = Time.time;

        AudioManager.Instance?.PlaySfx(SfxType.PlayerAttack);
    }

    private void HandleSkills()
    {
        if (Input.GetKeyDown(KeyCode.Q)) SkillManager.Instance.UseSkill("Q");
        else if (Input.GetKeyDown(KeyCode.W)) SkillManager.Instance.UseSkill("W");
        else if (Input.GetKeyDown(KeyCode.E)) SkillManager.Instance.UseSkill("E");
        else if (Input.GetKeyDown(KeyCode.R)) SkillManager.Instance.UseSkill("R");
    }
    #endregion

    #region Dash
    private void CheckDashInput()
    {
        if (!Input.GetKeyDown(KeyCode.LeftShift))
            return;

        if (Input.GetKey(KeyCode.LeftArrow))
            TryStartDash(-1).Forget();
        else if (Input.GetKey(KeyCode.RightArrow))
            TryStartDash(1).Forget();
    }

    private async UniTask TryStartDash(int direction)
    {
        if (model.isDashing) return;
        if (Time.time - model.lastDashTime < model.dashCooldown) return;

        await DashRoutine(direction);
    }

    private async UniTask DashRoutine(int direction)
    {
        model.SetDashing(true);
        model.lastDashTime = Time.time;
        dashTimer = 0f;

        AudioManager.Instance?.PlaySfx(SfxType.Dash);

        while (dashTimer < model.dashDuration)
        {
            dashTimer += Time.deltaTime;
            Vector2 velocity = view.GetVelocity();
            velocity.x = direction * model.dashSpeed;
            view.SetVelocity(velocity);
            await UniTask.Yield();
        }

        model.SetDashing(false);
    }

    private void HandleDash()
    {
        var emission = view.dashParticle.emission;
        emission.enabled = model.isDashing;

        if (model.isDashing && !view.dashParticle.isPlaying)
            view.dashParticle.Play();
    }
    #endregion

    #region Interaction
    private void HandleNPCInteraction()
    {
        if (ChatManager.Instance.IsUIBlockingInput)
            return;

        if (!Input.GetMouseButtonDown(0))
            return;

        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Collider2D[] hits = Physics2D.OverlapPointAll(mousePos);

        if (hits == null || hits.Length == 0)
            return;

        foreach (var h in hits)
        {
            NPC npc = h.GetComponentInParent<NPC>();
            if (npc != null)
            {
                npc.Talk();
                return;
            }
        }

        foreach (var h in hits)
        {
            IInteractable interactable = h.GetComponentInParent<IInteractable>();
            if (interactable != null)
            {
                interactable.Interact();
                return;
            }
        }
    }

    private void HandleInventory()
    {
        if (!Input.GetKeyDown(KeyCode.I))
            return;

        model.SetInventoryOpen(!model.isInventoryOpen);

        if (model.isInventoryOpen)
        {
            InventoryManager.Instance.OpenInventory();
            AudioManager.Instance?.PlaySfx(SfxType.OpenShop);
        }
        else
        {
            InventoryManager.Instance.CloseInventory();
        }
    }

    private void HandleConsumable()
    {
        if (Input.GetKeyDown(KeyCode.S))
            UseHPItem();
        else if (Input.GetKeyDown(KeyCode.D))
            UseMPItem();
    }

    private void HandleSkillUI()
    {
        if (!Input.GetKeyDown(KeyCode.K))
            return;

        if (ChatManager.Instance != null && ChatManager.Instance.IsUIBlockingInput)
            return;

        SkillManager.Instance.SkillUIEnable();
    }

    private void HandleMenuUI()
    {
        if (!Input.GetKeyDown(KeyCode.Escape))
            return;

        GameManager.Instance.OpenMenu();
    }

    #endregion

    private void ApplyDamage(Enemy enemy)
    {
        if (enemy == null) return;
        enemy.TakeDamage(model.Damage);
    }

    private void UseHPItem()
    {
        var invItem = PlayerEquipmentManager.Instance.equippedHPItem;
        if (invItem == null) return;

        if (invItem.item is not ConsumableItem consumable) return;

        model.currentHP = Mathf.Min(model.currentHP + consumable.HealHP, model.MaxHP);
        UIManager.Instance.SetHP((int)model.currentHP);

        InventoryManager.Instance.RemoveItem(invItem, 1);
        if (invItem.count <= 0)
            PlayerEquipmentManager.Instance.UnequipHP();

        ConsumableUI.Instance.Refresh();
        AudioManager.Instance?.PlaySfx(SfxType.PotionUse);
    }

    private void UseMPItem()
    {
        var invItem = PlayerEquipmentManager.Instance.equippedMPItem;
        if (invItem == null) return;

        if (invItem.item is not ConsumableItem consumable) return;

        model.currentMP = Mathf.Min(model.currentMP + consumable.HealMP, model.MaxMP);
        UIManager.Instance.SetMP((int)model.currentMP);

        InventoryManager.Instance.RemoveItem(invItem, 1);
        if (invItem.count <= 0)
            PlayerEquipmentManager.Instance.UnequipMP();

        ConsumableUI.Instance.Refresh();
        AudioManager.Instance?.PlaySfx(SfxType.PotionUse);
    }

    public void SyncUI()
    {
        UIManager.Instance.InitializeHP((int)model.currentHP, (int)model.MaxHP);
        UIManager.Instance.InitializeMP((int)model.currentMP, (int)model.MaxMP);
        UIManager.Instance.InitializeEXP(model.currentEXP, model.MaxEXP);
        UIManager.Instance.SetLevelText(model.Level);
    }

    private void OnDeath()
    {
        view.FreezeOnDeath();
        view.SetDeath();
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name != SceneLoader.TargetSceneName)
            return;

        if (scene.name == "Main")
        {
            model.currentHP = model.MaxHP;
            model.currentMP = model.MaxMP;
        }

        SyncUI();
        StartCoroutine(SpawnAfterSceneReady());
    }

    private IEnumerator SpawnAfterSceneReady()
    {
        yield return null;

        if (string.IsNullOrEmpty(SceneLoader.TargetSpawnPointID))
            yield break;

        var target = FindObjectsOfType<SpawnPoint>()
            .FirstOrDefault(p => p.spawnPointID == SceneLoader.TargetSpawnPointID);

        if (target == null)
            yield break;

        enabled = false;

        var rb = GetComponentInChildren<Rigidbody2D>();
        if (rb != null)
            rb.position = target.transform.position;
        else
            transform.position = target.transform.position;

        yield return null;
        enabled = true;
    }

    public void OnRespawn()
    {
        view.UnfreezeOnRespawn();
        view.EnableEdit();
    }
}
