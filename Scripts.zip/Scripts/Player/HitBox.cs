using Cysharp.Threading.Tasks;
using System;
using UnityEngine;

public class HitBox : MonoBehaviour
{
    private BoxCollider2D boxCollider;

    public event Action<Enemy> Hit;

    private void Awake()
    {
        boxCollider = GetComponent<BoxCollider2D>();
        boxCollider.enabled = false;
    }

    public void BasicAttack()
    {
        ShowImpactAsync().Forget();
    }

    private async UniTask ShowImpactAsync()
    {
        await UniTask.Delay(120);
        boxCollider.enabled = true;

        await UniTask.Delay(150);
        boxCollider.enabled = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Monster"))
            return;

        Enemy enemy = collision.GetComponent<Enemy>();
        if (enemy == null)
            return;

        Hit?.Invoke(enemy);
    }
}
