﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using DG.Tweening;

public class PlayerDeathController : MonoBehaviour
{
    public static PlayerDeathController Instance;

    [Header("Black Fade UI")]
    [SerializeField] private CanvasGroup blackFade;
    [SerializeField] private float fadeDuration = 1f;

    [Header("Respawn")]
    [SerializeField] private string townSceneName = "Main";
    [SerializeField] private string townSpawnPointName = "point";

    private PlayerModel pendingRespawnPlayer;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (blackFade != null)
            blackFade.alpha = 0f;

        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    public void HandlePlayerDeath(PlayerModel player)
    {
        pendingRespawnPlayer = player;
        StartCoroutine(DeathRoutine());
    }

    private IEnumerator DeathRoutine()
    {
        if (blackFade != null)
            blackFade.DOFade(1f, fadeDuration);

        yield return new WaitForSeconds(fadeDuration);

        SceneLoader.LoadScene(townSceneName, townSpawnPointName);
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name != townSceneName)
            return;

        if (pendingRespawnPlayer == null)
            return;

        Transform spawnPoint = GameObject.Find(townSpawnPointName)?.transform;
        if (spawnPoint != null)
            pendingRespawnPlayer.transform.position = spawnPoint.position;

        pendingRespawnPlayer.Respawn();

        var controller = pendingRespawnPlayer.GetComponent<PlayerController>();
        if (controller != null)
            controller.OnRespawn();

        pendingRespawnPlayer = null;

        if (blackFade != null)
            blackFade.DOFade(0f, fadeDuration);
    }
}
