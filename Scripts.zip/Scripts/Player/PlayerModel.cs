﻿using System;
using UnityEngine;

public class PlayerModel : MonoBehaviour
{
    [Header("Level / EXP")]
    [SerializeField] private int level = 1;
    [SerializeField] private int maxEXP = 100;

    public int Level => level;
    public int MaxEXP => maxEXP;

    [Header("Base Stats")]
    [SerializeField] private float baseMaxHP = 100;
    [SerializeField] private float baseMaxMP = 50;
    [SerializeField] private float baseDamage = 10;
    [SerializeField] private float baseDefense = 0;

    private float bonusMaxHP;
    private float bonusMaxMP;
    private float bonusDamage;
    private float bonusDefense;

    [Header("Current")]
    public float currentHP;
    public float currentMP;
    public int currentEXP;

    [Header("Movement")]
    public float moveSpeed = 5f;
    public float jumpForce = 10f;
    public float dashSpeed = 15f;
    public float dashDuration = 0.2f;
    public float dashCooldown = 1f;
    public float lastDashTime = -10f;

    [Header("State")]
    [SerializeField] private bool isDead;
    public bool IsDead => isDead;

    public float MaxHP => baseMaxHP + bonusMaxHP;
    public float MaxMP => baseMaxMP + bonusMaxMP;
    public float Damage => baseDamage + bonusDamage;
    public float Defense => baseDefense + bonusDefense;

    public bool isGrounded { get; private set; }
    public bool isJumping { get; private set; }
    public bool isDashing { get; private set; }
    public bool isInventoryOpen { get; private set; }

    public event Action onLevelUp;
    public event Action onDie;

    private void Awake()
    {
        currentHP = MaxHP;
        currentMP = MaxMP;
    }

    private void OnEnable()
    {
        ExpEvent.OnAddExp += GetExp;
    }

    private void OnDisable()
    {
        ExpEvent.OnAddExp -= GetExp;
    }

    #region State
    public void SetDashing(bool v) => isDashing = v;
    public void SetGrounded(bool v) => isGrounded = v;
    public void SetJumping(bool v) => isJumping = v;
    public void SetInventoryOpen(bool v) => isInventoryOpen = v;
    #endregion

    #region HP / MP
    public bool TryConsumeMP(float value)
    {
        if (value <= 0) return true;
        if (isDead) return false;

        if (currentMP < value)
        {
            Debug.LogWarning("[플레이어] 마나가 부족합니다.");
            return false;
        }

        currentMP -= value;
        UIManager.Instance.SetMP((int)currentMP);
        return true;
    }
    #endregion

    #region EXP
    public void GetExp(int exp)
    {
        currentEXP += exp;

        while (currentEXP >= maxEXP)
        {
            currentEXP -= maxEXP;
            LevelUp();
        }

        UIManager.Instance.SetEXP(currentEXP);
    }

    private void LevelUp()
    {
        level++;
        maxEXP = Mathf.FloorToInt(maxEXP * 2.5f);

        baseMaxHP *= 1.5f;
        baseMaxMP *= 1.5f;
        baseDamage *= 1.5f;

        currentHP = MaxHP;
        currentMP = MaxMP;

        onLevelUp?.Invoke();
        AudioManager.Instance?.PlaySfx(SfxType.LevelUp);
        SaveManager.Instance.SaveGame();
    }
    #endregion

    public void TakeDamage(float damage)
    {
        if (isDead) return;

        damage = Mathf.Max(1, damage - Defense);
        currentHP -= damage;

        UIManager.Instance.SetHP((int)currentHP);
        AudioManager.Instance?.PlaySfx(SfxType.PlayerHit);

        if (currentHP <= 0)
            Die();
    }

    private void Die()
    {
        if (isDead) return;

        isDead = true;

        int penalty = Mathf.CeilToInt(maxEXP * 0.05f);
        currentEXP = Mathf.Max(0, currentEXP - penalty);
        UIManager.Instance.SetEXP(currentEXP);

        AudioManager.Instance?.PlaySfx(SfxType.PlayerDie);
        onDie?.Invoke();

        PlayerDeathController.Instance?.HandlePlayerDeath(this);
    }

    public void FillSaveData(SaveData data)
    {
        data.level = level;
        data.currentEXP = currentEXP;
        data.maxEXP = maxEXP;

        data.baseMaxHP = baseMaxHP;
        data.baseMaxMP = baseMaxMP;
        data.baseDamage = baseDamage;
        data.baseDefense = baseDefense;
    }

    public void ApplySaveData(SaveData data)
    {
        level = data.level;
        currentEXP = data.currentEXP;
        maxEXP = data.maxEXP;

        baseMaxHP = data.baseMaxHP;
        baseMaxMP = data.baseMaxMP;
        baseDamage = data.baseDamage;
        baseDefense = data.baseDefense;

        currentHP = MaxHP;
        currentMP = MaxMP;
        isDead = false;
    }

    public void Respawn()
    {
        currentHP = MaxHP;
        currentMP = MaxMP;
        UIManager.Instance.SetHP((int)currentHP);
        UIManager.Instance.SetMP((int)currentMP);
        isDead = false;
    }

    public void AddDamage(float value)
    {
        bonusDamage += value;
    }

    public void RemoveDamage(float value)
    {
        bonusDamage -= value;
    }

    public void AddDefense(float value)
    {
        bonusDefense += value;
    }

    public void RemoveDefense(float value)
    {
        bonusDefense -= value;
    }

    public void AddMaxHP(float value)
    {
        bonusMaxHP += value;

        currentHP = Mathf.Min(currentHP, MaxHP);
        UIManager.Instance?.SetHP((int)currentHP);
    }

    public void RemoveMaxHP(float value)
    {
        bonusMaxHP -= value;

        currentHP = Mathf.Min(currentHP, MaxHP);
        UIManager.Instance?.SetHP((int)currentHP);
    }

    public void AddMaxMP(float value)
    {
        bonusMaxMP += value;

        currentMP = Mathf.Min(currentMP, MaxMP);
        UIManager.Instance?.SetMP((int)currentMP);
    }

    public void RemoveMaxMP(float value)
    {
        bonusMaxMP -= value;

        currentMP = Mathf.Min(currentMP, MaxMP);
        UIManager.Instance?.SetMP((int)currentMP);
    }

    public void HealHP(float value)
    {
        if (value <= 0f) return;

        currentHP = Mathf.Min(currentHP + value, MaxHP);
        UIManager.Instance?.SetHP((int)currentHP);
    }

    public void HealMP(float value)
    {
        if (value <= 0f) return;

        currentMP = Mathf.Min(currentMP + value, MaxMP);
        UIManager.Instance?.SetMP((int)currentMP);
    }
}
