﻿using System.Collections.Generic;
using UnityEngine;

public class PlayerEquipmentManager : MonoBehaviour
{
    public static PlayerEquipmentManager Instance;

    [SerializeField] private PlayerModel player;

    private readonly Dictionary<EquipSlot, InventoryItem> equippedItems = new();

    public InventoryItem equippedHPItem;
    public InventoryItem equippedMPItem;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public bool IsEquipped(InventoryItem inventoryItem)
    {
        if (inventoryItem == null)
            return false;

        Item item = inventoryItem.item;

        if (item is ConsumableItem consumable)
        {
            if (consumable.HealHP > 0)
                return equippedHPItem == inventoryItem;

            if (consumable.HealMP > 0)
                return equippedMPItem == inventoryItem;

            return false;
        }

        EquipSlot slot = item.EquipSlot;
        return equippedItems.TryGetValue(slot, out InventoryItem equipped)
               && equipped == inventoryItem;
    }

    public InventoryItem GetEquippedItem(EquipSlot slot)
    {
        equippedItems.TryGetValue(slot, out InventoryItem item);
        return item;
    }

    public bool Equip(InventoryItem inventoryItem)
    {
        if (inventoryItem == null)
            return false;

        Item item = inventoryItem.item;

        if (item is ConsumableItem)
        {
            EquipSlot slot = item.EquipSlot;

            if (slot == EquipSlot.HP)
            {
                equippedHPItem = inventoryItem;
                equippedItems[EquipSlot.HP] = inventoryItem;
            }
            else if (slot == EquipSlot.MP)
            {
                equippedMPItem = inventoryItem;
                equippedItems[EquipSlot.MP] = inventoryItem;
            }
            else
            {
                return false;
            }

            RefreshUI();
            AudioManager.Instance?.PlaySfx(SfxType.Equip);
            return true;
        }

        EquipSlot equipSlot = item.EquipSlot;
        if (equipSlot == EquipSlot.Etc)
            return false;

        if (equippedItems.ContainsKey(equipSlot))
            Unequip(equipSlot);

        equippedItems[equipSlot] = inventoryItem;
        ApplyStat(item);

        RefreshUI();
        AudioManager.Instance?.PlaySfx(SfxType.Equip);
        return true;
    }

    public void Unequip(EquipSlot slot)
    {
        if (!equippedItems.TryGetValue(slot, out InventoryItem item))
            return;

        if (slot == EquipSlot.HP)
            equippedHPItem = null;
        else if (slot == EquipSlot.MP)
            equippedMPItem = null;
        else
            RemoveStat(item.item);

        equippedItems.Remove(slot);
        RefreshUI();
    }

    private void ApplyStat(Item item)
    {
        if (item is WeaponItem w)
        {
            player.AddDamage(w.AttackPower);
            player.AddDefense(w.DefensePower);
            player.AddMaxHP(w.HP);
            player.AddMaxMP(w.MP);

            player.HealHP(w.HP);
            player.HealMP(w.MP);
        }
    }

    private void RemoveStat(Item item)
    {
        if (item is WeaponItem w)
        {
            player.RemoveDamage(w.AttackPower);
            player.RemoveDefense(w.DefensePower);
            player.RemoveMaxHP(w.HP);
            player.RemoveMaxMP(w.MP);
        }

        player.currentHP = Mathf.Min(player.currentHP, player.MaxHP);
        player.currentMP = Mathf.Min(player.currentMP, player.MaxMP);
    }

    public void UnequipHP()
    {
        equippedHPItem = null;
        equippedItems.Remove(EquipSlot.HP);
        RefreshUI();
    }

    public void UnequipMP()
    {
        equippedMPItem = null;
        equippedItems.Remove(EquipSlot.MP);
        RefreshUI();
    }

    private void RefreshUI()
    {
        InventoryManager.Instance.SetUIState();
        InventoryManager.Instance.RefreshPlayerSlots();
        InventoryManager.Instance.RefreshInventoryUI();

        if (ConsumableUI.Instance != null)
            ConsumableUI.Instance.Refresh();

        UIManager.Instance.InitializeHP((int)player.currentHP, (int)player.MaxHP);
        UIManager.Instance.InitializeMP((int)player.currentMP, (int)player.MaxMP);
    }
}
