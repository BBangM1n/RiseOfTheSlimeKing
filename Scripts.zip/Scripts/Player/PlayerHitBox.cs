using System.Collections;
using UnityEngine;

public class PlayerHitBox : MonoBehaviour
{
    [Header("Invincibility")]
    [SerializeField] private float invincibleDuration = 1f;

    [Header("Blink")]
    [SerializeField] private float blinkInterval = 0.08f;

    private PlayerModel model;
    private bool isInvincible;
    private Coroutine invCoroutine;

    private SpriteRenderer[] renderers;
    private bool originalEnabled = true;

    private void Awake()
    {
        model = GetComponentInParent<PlayerModel>();
        if (model == null)
            Debug.LogError("[�÷��̾� �ǰ�] PlayerModel�� �θ𿡼� ã�� ���߽��ϴ�.");

        renderers = model != null
            ? model.GetComponentsInChildren<SpriteRenderer>(true)
            : GetComponentsInChildren<SpriteRenderer>(true);

        if (renderers != null && renderers.Length > 0)
            originalEnabled = renderers[0].enabled;
    }

    private void OnTriggerEnter2D(Collider2D other) => TryTakeContactDamage(other);
    private void OnTriggerStay2D(Collider2D other) => TryTakeContactDamage(other);

    private void TryTakeContactDamage(Collider2D other)
    {
        if (model == null || isInvincible || model.IsDead)
            return;

        MonsterHitBox zone = other.GetComponent<MonsterHitBox>();
        if (zone == null || zone.Owner == null)
            return;

        float dmg = zone.Owner.Damage;
        if (dmg <= 0f)
            return;

        model.TakeDamage(dmg);
        StartInvincibility();
    }

    private void StartInvincibility()
    {
        isInvincible = true;

        if (invCoroutine != null)
            StopCoroutine(invCoroutine);

        invCoroutine = StartCoroutine(InvincibilityRoutine());
    }

    private IEnumerator InvincibilityRoutine()
    {
        float elapsed = 0f;
        bool visible = true;

        while (elapsed < invincibleDuration)
        {
            visible = !visible;
            SetRenderersEnabled(visible);

            yield return new WaitForSeconds(blinkInterval);
            elapsed += blinkInterval;
        }

        SetRenderersEnabled(originalEnabled);
        isInvincible = false;
        invCoroutine = null;
    }

    private void SetRenderersEnabled(bool value)
    {
        if (renderers == null)
            return;

        foreach (var r in renderers)
        {
            if (r != null)
                r.enabled = value;
        }
    }
}
