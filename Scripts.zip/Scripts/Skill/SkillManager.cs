﻿using System.Collections.Generic;
using UnityEngine;

public class SkillManager : MonoBehaviour
{
    [System.Serializable]
    public class SkillSlot
    {
        public int Code;
        public string Damage;
        public string CoolTime;
        public Texture Image;
    }

    public static SkillManager Instance { get; private set; }

    [SerializeField] private SkillContainer skillContainer;
    [SerializeField] private SkillButton[] skillButtons;
    [SerializeField] private SkillUI skillUI;
    [SerializeField] private PlayerModel playerModel;
    [SerializeField] private GameObject blockPanel;

    private Dictionary<string, SkillButton> skillButtonMap;
    private Dictionary<int, SkillUIPrefab> skillUIMap = new();

    public PlayerModel PlayerModel => playerModel;
    public SkillSlot skillslot;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        skillButtonMap = new Dictionary<string, SkillButton>
        {
            { "Q", skillButtons[0] },
            { "W", skillButtons[1] },
            { "E", skillButtons[2] },
            { "R", skillButtons[3] }
        };

        foreach (var slot in skillButtons)
        {
            slot.Init();
            slot.Code += SetSkill;
            slot.button.interactable = false;
        }
    }

    private void Start()
    {
        skillUI.Init();
        blockPanel.SetActive(false);
    }

    private void OnEnable()
    {
        if (playerModel != null)
            playerModel.onLevelUp += OnPlayerLevelUp;
    }

    private void OnDisable()
    {
        if (playerModel != null)
            playerModel.onLevelUp -= OnPlayerLevelUp;
    }

    public void SetMode()
    {
        blockPanel.SetActive(true);

        foreach (var slot in skillButtons)
            slot.button.interactable = true;
    }

    public void RegisterSkillUI(SkillUIPrefab ui)
    {
        if (ui == null) return;
        skillUIMap[ui.SkillCode] = ui;
    }

    public void SetSkill(string key)
    {
        if (!skillButtonMap.TryGetValue(key, out SkillButton skillButton))
            return;

        int newCode = skillslot.Code;

        if (!ExcelReader.Instance.dicSkill.TryGetValue(newCode, out SkillData data))
        {
            Debug.LogError($"[스킬 매니저] SkillData를 찾을 수 없습니다: {newCode}");
            return;
        }

        if (playerModel.Level < data.RequiredLevel)
            return;

        if (newCode < 0 || newCode >= skillContainer.Skills.Length)
        {
            Debug.LogError($"[스킬 매니저] 잘못된 스킬 코드: {newCode}");
            return;
        }

        GameObject prefab = skillContainer.Skills[newCode];
        int oldCode = skillButton.SkillCode;

        skillButton.SetSkill(prefab, playerModel.transform, skillslot.Image, data, playerModel);

        if (skillUIMap.TryGetValue(newCode, out SkillUIPrefab newUI))
            newUI.SetEquipped(true);

        if (oldCode >= 0 && oldCode != newCode)
        {
            if (skillUIMap.TryGetValue(oldCode, out SkillUIPrefab oldUI))
                oldUI.SetEquipped(false);
        }

        foreach (var slot in skillButtons)
            slot.button.interactable = false;

        blockPanel.SetActive(false);
    }

    public void UnEquipSkill(int skillCode)
    {
        foreach (var btn in skillButtons)
        {
            if (btn.SkillCode == skillCode)
                btn.ClearSkill();
        }

        if (skillUIMap.TryGetValue(skillCode, out SkillUIPrefab ui))
            ui.SetEquipped(false);
    }

    public void SkillUIEnable()
    {
        bool active = skillUI.gameObject.activeSelf;
        skillUI.SkillUiActive(!active);
    }

    public void UseSkill(string key)
    {
        if (skillButtonMap.TryGetValue(key, out SkillButton skillButton))
            skillButton.TryUseSkill();
    }

    private void OnPlayerLevelUp()
    {
        UpdateAllSkillUILocks();
    }

    public void UpdateAllSkillUILocks()
    {
        foreach (var kv in skillUIMap)
            kv.Value?.RefreshLockState();
    }

    public void FillSaveData(SaveData data)
    {
        data.equippedSkills ??= new List<EquippedSkillSave>();
        data.equippedSkills.Clear();

        foreach (var kvp in skillButtonMap)
        {
            if (kvp.Value.SkillCode < 0) continue;

            data.equippedSkills.Add(new EquippedSkillSave
            {
                key = kvp.Key,
                skillCode = kvp.Value.SkillCode
            });
        }
    }

    public void ApplySaveData(SaveData data)
    {
        if (data.equippedSkills == null)
            return;

        foreach (var btn in skillButtons)
            btn.ClearSkill();

        foreach (var eq in data.equippedSkills)
        {
            if (!skillButtonMap.TryGetValue(eq.key, out SkillButton btn))
                continue;

            if (!ExcelReader.Instance.dicSkill.TryGetValue(eq.skillCode, out SkillData sData))
                continue;

            if (eq.skillCode < 0 || eq.skillCode >= skillContainer.Skills.Length)
                continue;

            GameObject prefab = skillContainer.Skills[eq.skillCode];

            Texture iconTexture = null;
            if (skillUIMap.TryGetValue(eq.skillCode, out SkillUIPrefab ui))
                iconTexture = ui.GetIconTexture();

            btn.SetSkill(prefab, playerModel.transform, iconTexture, sData, playerModel);

            if (ui != null)
                ui.SetEquipped(true);
        }

        UpdateAllSkillUILocks();
    }

    public void RefreshSlotIcons()
    {
        foreach (var kvp in skillButtonMap)
        {
            SkillButton btn = kvp.Value;
            int code = btn.SkillCode;
            if (code < 0) continue;

            if (!skillUIMap.TryGetValue(code, out SkillUIPrefab ui))
                continue;

            Texture tex = ui.GetIconTexture();
            if (tex != null)
                btn.SetIcon(tex);
        }
    }
}
