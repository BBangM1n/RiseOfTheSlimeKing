﻿using System.Collections;
using UnityEngine;

public class Samurai_Anger : SkillBase
{
    [SerializeField] private float buffDuration = 30f;
    [SerializeField] private Vector3 followOffset = new Vector3(0f, 1f, 0f);

    private Coroutine buffRoutine;
    private PlayerModel targetPlayer;
    private Transform targetTransform;
    private float appliedBuffAmount;

    public override void SetDirection(Vector3 direction) { }
    protected override void Move() { }

    protected override void Update()
    {
        if (targetTransform != null)
            transform.position = targetTransform.position + followOffset;
    }

    public override void ActivateSkill(Vector3 direction)
    {
        if (buffRoutine != null)
            return;

        PlayerModel pm = owner ?? SkillManager.Instance?.PlayerModel;
        if (pm == null)
        {
            Debug.LogError("[분노] 플레이어 정보를 찾지 못했습니다.");
            Release();
            return;
        }

        targetPlayer = pm;
        targetTransform = pm.transform;
        transform.position = targetTransform.position + followOffset;

        buffRoutine = StartCoroutine(BuffRoutine());
    }

    private IEnumerator BuffRoutine()
    {
        float baseDamage = targetPlayer.Damage;
        float percent = DamagePercent * 0.01f;

        appliedBuffAmount = Mathf.Round(baseDamage * percent);
        targetPlayer.AddDamage(appliedBuffAmount);

        yield return new WaitForSeconds(buffDuration);

        if (targetPlayer != null && appliedBuffAmount != 0f)
            targetPlayer.RemoveDamage(appliedBuffAmount);

        appliedBuffAmount = 0f;
        buffRoutine = null;
        targetPlayer = null;
        targetTransform = null;

        Release();
    }

    private void OnDisable()
    {
        if (targetPlayer != null && appliedBuffAmount != 0f)
            targetPlayer.RemoveDamage(appliedBuffAmount);

        appliedBuffAmount = 0f;
        buffRoutine = null;
        targetPlayer = null;
        targetTransform = null;
    }
}
