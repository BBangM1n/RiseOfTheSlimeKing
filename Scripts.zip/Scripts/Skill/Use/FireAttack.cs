using UnityEngine;

public class FireAttack : SkillBase
{
    private Vector3 moveDirection;
    public float heightOffset = 0.5f;

    public override void SetDirection(Vector3 direction)
    {
        moveDirection = direction.normalized;

        transform.position = new Vector3(
            transform.position.x,
            transform.position.y + heightOffset,
            transform.position.z
        );

        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null)
            sr.flipX = direction.x < 0;
    }

    protected override void Move()
    {
        transform.position += moveDirection * speed * Time.deltaTime;
    }
}
