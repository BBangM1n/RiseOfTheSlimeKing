﻿using System.Collections;
using UnityEngine;

public class Samurai_Ilseom : SkillBase
{
    [Header("Area Settings")]
    [SerializeField] private BoxCollider2D areaCollider;
    [SerializeField] private LayerMask monsterLayer;

    [Header("Visual")]
    [SerializeField] private float lifeTime = 0.8f;

    [Header("Spawn Offset")]
    [SerializeField] private Vector3 spawnOffset = new Vector3(0.5f, 0f, 0f);

    private Vector3 lookDirection = Vector3.right;

    private void Reset()
    {
        areaCollider = GetComponent<BoxCollider2D>();
    }

    public override void SetDirection(Vector3 direction)
    {
        if (direction == Vector3.zero)
            direction = Vector3.right;

        lookDirection = direction.normalized;

        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null)
        {
            sr.flipX = (lookDirection.x < 0);
        }
    }

    protected override void Move()
    {

    }

    protected override void Update()
    {

    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {

    }

    public override void ActivateSkill(Vector3 direction)
    {
        if (owner == null)
        {
            Debug.LogError("[Samurai_Ilseom] owner(PlayerModel)가 없습니다.");
            Release();
            return;
        }

        SetDirection(direction);

        Vector3 offset = spawnOffset;

        if (lookDirection.x < 0)
            offset.x = -Mathf.Abs(spawnOffset.x);
        else
            offset.x = Mathf.Abs(spawnOffset.x);

        Transform ownerTf = owner.transform;
        transform.position = ownerTf.position + offset;

        StartCoroutine(AttackRoutine());
    }

    private IEnumerator AttackRoutine()
    {
        if (areaCollider == null)
        {
            areaCollider = GetComponent<BoxCollider2D>();
            if (areaCollider == null)
            {
                Debug.LogError("[Samurai_Ilseom] BoxCollider2D가 없습니다.");
                Release();
                yield break;
            }
        }

        Vector2 center = (Vector2)transform.position + areaCollider.offset;

        Vector2 size = new Vector2(
            areaCollider.size.x * Mathf.Abs(transform.lossyScale.x),
            areaCollider.size.y * Mathf.Abs(transform.lossyScale.y)
        );

        float angle = transform.eulerAngles.z;

        Collider2D[] hits = Physics2D.OverlapBoxAll(
            center,
            size,
            angle,
            monsterLayer
        );

        int hitCount = 0;

        foreach (var hit in hits)
        {
            if (hit == null) continue;
            if (!hit.CompareTag("Monster")) continue;

            Enemy enemy = hit.GetComponent<Enemy>()
                         ?? hit.GetComponentInParent<Enemy>()
                         ?? hit.GetComponentInChildren<Enemy>();

            if (enemy != null)
            {
                enemy.TakeDamage(Damage);
                hitCount++;
            }
        }

        yield return new WaitForSeconds(lifeTime);

        Release();
    }

    private void OnDrawGizmosSelected()
    {
        if (areaCollider == null) return;

        Vector2 center = Application.isPlaying
            ? (Vector2)transform.position + areaCollider.offset
            : (Vector2)transform.position + (Vector2)areaCollider.offset;

        Vector2 size = new Vector2(
            areaCollider.size.x * Mathf.Abs(transform.lossyScale.x),
            areaCollider.size.y * Mathf.Abs(transform.lossyScale.y)
        );

        Gizmos.color = new Color(0.4f, 0.8f, 1f, 0.4f);
        Gizmos.DrawCube(center, size);
    }
}
