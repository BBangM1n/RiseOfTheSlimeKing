﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Samurai_Prick : SkillBase
{
    [Header("Prick Settings")]
    [SerializeField] private float dashDistance = 5f;
    [SerializeField] private float hitRadius = 0.5f;
    [SerializeField] private LayerMask monsterLayer;

    [Header("Effect Settings")]
    [SerializeField] private float effectDuration = 0.3f;

    private Vector3 dashDirection = Vector3.right;

    public override void SetDirection(Vector3 direction)
    {
        if (direction == Vector3.zero)
            direction = Vector3.right;

        dashDirection = direction.normalized;

        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null)
        {
            sr.flipX = dashDirection.x < 0;
        }
    }

    protected override void Move()
    {
    }

    protected override void Update()
    {
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
    }

    public override void ActivateSkill(Vector3 direction)
    {
        if (owner == null)
        {
            Debug.LogError("[Samurai_Prick] owner(PlayerModel)가 없습니다.");
            Release();
            return;
        }

        SetDirection(direction);

        StartCoroutine(PrickRoutine());
    }

    private IEnumerator PrickRoutine()
    {
        Transform ownerTf = owner.transform;

        Vector3 startPos = ownerTf.position;
        Vector3 endPos = startPos + dashDirection * dashDistance;

        HashSet<Enemy> hitEnemies = new HashSet<Enemy>();

        int steps = 6;
        for (int i = 0; i <= steps; i++)
        {
            float t = i / (float)steps;
            Vector2 checkPos = Vector2.Lerp(startPos, endPos, t);

            Collider2D[] cols = Physics2D.OverlapCircleAll(
                checkPos,
                hitRadius,
                monsterLayer
            );

            foreach (var col in cols)
            {
                if (col == null) continue;

                Enemy enemy = col.GetComponent<Enemy>()
                            ?? col.GetComponentInParent<Enemy>()
                            ?? col.GetComponentInChildren<Enemy>();

                if (enemy != null && !hitEnemies.Contains(enemy))
                {
                    enemy.TakeDamage(Damage);
                    hitEnemies.Add(enemy);
                }
            }
        }

        Debug.Log($"[Samurai_Prick] 타격 몬스터 수: {hitEnemies.Count}");

        ownerTf.position = endPos;

        if (effectDuration > 0f)
            yield return new WaitForSeconds(effectDuration);

        Release();
    }

    private void OnDrawGizmosSelected()
    {
        Vector3 origin = owner != null ? owner.transform.position : transform.position;

        Gizmos.color = new Color(1f, 0.3f, 0.3f, 0.5f);

        Vector3 dir = (dashDirection == Vector3.zero ? Vector3.right : dashDirection.normalized);
        Vector3 startPos = origin;
        Vector3 endPos = startPos + dir * dashDistance;

        Gizmos.DrawLine(startPos, endPos);

        int steps = 6;
        for (int i = 0; i <= steps; i++)
        {
            float t = i / (float)steps;
            Vector3 pos = Vector3.Lerp(startPos, endPos, t);
            Gizmos.DrawWireSphere(pos, hitRadius);
        }
    }
}
