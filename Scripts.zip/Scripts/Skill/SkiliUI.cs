﻿using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class SkillUI : MonoBehaviour
{
    [SerializeField] private GameObject skillScreen;
    [SerializeField] private Transform contentParent;
    [SerializeField] private ExplanScreen explanScreen;
    [SerializeField] private GameObject skillUIPrefab;

    private bool built = false;

    public void Init()
    {
        BuildIfNeeded();
        SkillUiActive(false);
    }

    private void BuildIfNeeded()
    {
        if (built) return;

        if (ExcelReader.Instance == null || ExcelReader.Instance.dicSkill == null || ExcelReader.Instance.dicSkill.Count == 0)
        {
            Debug.LogWarning("[스킬 UI] dicSkill이 비어있어서 스킬 UI를 만들 수 없습니다. (데이터 로드 타이밍 확인 필요)");
            return;
        }

        for (int i = contentParent.childCount - 1; i >= 0; i--)
            Destroy(contentParent.GetChild(i).gameObject);

        foreach (var kv in ExcelReader.Instance.dicSkill.OrderBy(k => k.Key))
        {
            SkillData info = kv.Value;
            GameObject skillUIObj = Instantiate(skillUIPrefab, contentParent);

            SkillUIPrefab ui = skillUIObj.GetComponent<SkillUIPrefab>();
            if (ui != null) ui.SetUI(info);
            else Debug.LogError("[스킬 UI] SkillUIPrefab에 SkillUIPrefab 스크립트가 없습니다.");
        }

        explanScreen?.Init();
        built = true;
    }

    public void SkillUiActive(bool active)
    {
        if (active) BuildIfNeeded();
        skillScreen.SetActive(active);
    }
}
