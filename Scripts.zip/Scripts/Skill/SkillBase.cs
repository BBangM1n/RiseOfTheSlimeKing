﻿using UnityEngine;

public abstract class SkillBase : MonoBehaviour
{
    [Header("Skill Settings")]
    [SerializeField] protected float speed = 10f;
    [SerializeField] protected float lifetime = 3f;

    [Header("Stat")]
    [SerializeField] protected float damage = 100f;

    [Header("Pool")]
    [SerializeField] private string poolKey;
    public string PoolKey => poolKey;

    protected PlayerModel owner;

    public void SetOwner(PlayerModel player)
    {
        owner = player;
    }

    public float DamagePercent => damage;

    public float Damage
    {
        get
        {
            if (owner == null)
                return Mathf.Max(1f, damage);

            float baseDamage = owner.Damage;
            float result = baseDamage * (damage * 0.01f);
            return Mathf.Max(1f, result);
        }
    }

    public int Code { get; private set; } = -1;
    public float Cooldown { get; protected set; }

    protected float spawnTime;

    protected virtual void OnEnable()
    {
        spawnTime = Time.time;
    }

    public void SetCode(int code)
    {
        Code = code;
    }

    public virtual void ApplyData(SkillData data)
    {
        damage = data.Damage;
        Cooldown = data.CoolTime;
        Code = data.Code;
    }

    public virtual void ActivateSkill(Vector3 direction)
    {
        SetDirection(direction);
    }

    protected virtual void Update()
    {
        Move();
        CheckLifetime();
    }

    public abstract void SetDirection(Vector3 direction);
    protected abstract void Move();

    private void CheckLifetime()
    {
        if (Time.time - spawnTime >= lifetime)
            Release();
    }

    protected virtual void Release()
    {
        if (!string.IsNullOrEmpty(poolKey) && PoolManager.Instance != null)
            PoolManager.Instance.ReleaseObject(poolKey, gameObject);
        else
            Destroy(gameObject);
    }

    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Monster"))
            return;

        Enemy enemy = collision.GetComponent<Enemy>();
        if (enemy != null)
            enemy.TakeDamage(Damage);

        Release();
    }
}
