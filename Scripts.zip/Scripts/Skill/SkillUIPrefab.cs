﻿using System;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.UI;

public class SkillUIPrefab : MonoBehaviour
{
    [SerializeField] private Text skillName;
    [SerializeField] private RawImage skillImage;
    [SerializeField] private Text skillLv;
    [SerializeField] private Button skillSetButton;
    [SerializeField] private Button skillExplanButton;
    [SerializeField] private GameObject lockPanel;
    [SerializeField] private Button unSetButton;

    public int Level = 0;

    public int SkillCode { get; private set; }
    private SkillData data;

    public event Action<string, string, Texture, string, string> info;

    private bool IsUnlocked
    {
        get
        {
            var player = SkillManager.Instance.PlayerModel;
            if (player == null) return true;
            return player.Level >= data.RequiredLevel;
        }
    }

    private void OnClickSet()
    {
        if (!IsUnlocked)
            return;

        SkillManager.Instance.skillslot.Code = data.Code;
        SkillManager.Instance.skillslot.Image = skillImage.texture;
        SkillManager.Instance.skillslot.Damage = data.Damage.ToString();
        SkillManager.Instance.skillslot.CoolTime = data.CoolTime.ToString();

        SkillManager.Instance.SetMode();
    }

    private void OnClickUnSet()
    {
        SkillManager.Instance.UnEquipSkill(SkillCode);
    }

    public void SetUI(SkillData data)
    {
        this.data = data;
        SkillCode = data.Code;
        Level = data.RequiredLevel;

        skillName.text = data.Name;
        skillLv.text = $"Lv. {data.RequiredLevel}";

        Addressables.LoadAssetAsync<Texture>(data.Key).Completed += OnIconLoaded;

        skillExplanButton.onClick.RemoveAllListeners();
        skillExplanButton.onClick.AddListener(() =>
        {
            info?.Invoke(
                data.Name,
                data.Explain,
                skillImage.texture,
                data.MpCost.ToString(),
                data.CoolTime.ToString()
            );
        });

        skillSetButton.onClick.RemoveAllListeners();
        skillSetButton.onClick.AddListener(OnClickSet);

        if (unSetButton != null)
        {
            unSetButton.onClick.RemoveAllListeners();
            unSetButton.onClick.AddListener(OnClickUnSet);
        }

        SkillManager.Instance.RegisterSkillUI(this);
        RefreshLockState();
        SetEquipped(false);
    }

    private void OnIconLoaded(AsyncOperationHandle<Texture> handle)
    {
        if (handle.Status == AsyncOperationStatus.Succeeded)
            skillImage.texture = handle.Result;
        else
            Debug.LogError($"[스킬 UI] 아이콘 로드 실패: {data.Key}");
    }

    public void SetEquipped(bool equipped)
    {
        if (skillSetButton != null)
            skillSetButton.gameObject.SetActive(!equipped);

        if (unSetButton != null)
            unSetButton.gameObject.SetActive(equipped);
    }

    public void RefreshLockState()
    {
        bool unlocked = IsUnlocked;

        if (lockPanel != null)
            lockPanel.SetActive(!unlocked);

        if (skillSetButton != null)
            skillSetButton.interactable = unlocked;
    }

    public Texture GetIconTexture()
    {
        return skillImage != null ? skillImage.texture : null;
    }
}
