using UnityEngine;

public class SkillContainer : MonoBehaviour
{
    public GameObject[] Skills;
}
