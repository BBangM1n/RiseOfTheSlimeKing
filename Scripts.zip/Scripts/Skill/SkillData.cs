﻿[System.Serializable]
public class SkillData
{
    public int Code;
    public string Name;
    public string Key;
    public string Explain;

    public float Damage;

    public float CoolTime;

    public float MpCost;

    public int RequiredLevel;
}
