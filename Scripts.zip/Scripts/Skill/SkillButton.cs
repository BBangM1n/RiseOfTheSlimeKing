﻿using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.UI;

public class SkillButton : MonoBehaviour
{
    [SerializeField] private string SlotCode;
    [SerializeField] private RawImage rawimage;
    [SerializeField] private Image cooldownMask;

    public GameObject skillPrefab;
    public Transform skillTransform;
    public Button button;

    public event System.Action<string> Code;

    private string poolKey;
    private SkillData skillData;
    private PlayerModel owner;

    public int SkillCode { get; private set; } = -1;

    public float cooldownDuration;
    private float cooldownRemaining;
    public bool IsOnCooldown => cooldownRemaining > 0f;

    private void Update()
    {
        if (cooldownRemaining > 0f)
        {
            cooldownRemaining -= Time.deltaTime;
            if (cooldownRemaining < 0f)
                cooldownRemaining = 0f;

            if (cooldownMask != null && cooldownDuration > 0f)
                cooldownMask.fillAmount = cooldownRemaining / cooldownDuration;
        }
    }

    public void Init()
    {
        button.onClick.AddListener(() =>
        {
            Code?.Invoke(SlotCode);
        });

        cooldownRemaining = 0f;
        if (cooldownMask != null)
            cooldownMask.fillAmount = 0f;
    }

    public void SetSkill(GameObject prefab, Transform skillpoint, Texture texture, SkillData data, PlayerModel owner)
    {
        skillPrefab = prefab;
        skillTransform = skillpoint;
        skillData = data;
        this.owner = owner;

        SkillCode = data.Code;

        if (texture != null)
        {
            rawimage.texture = texture;
        }
        else
        {
            rawimage.texture = null;
            Addressables.LoadAssetAsync<Texture>(data.Key).Completed += OnIconLoaded;
        }

        cooldownDuration = Mathf.Max(0f, data.CoolTime);
        cooldownRemaining = 0f;
        if (cooldownMask != null)
            cooldownMask.fillAmount = 0f;

        SkillBase baseComp = skillPrefab.GetComponent<SkillBase>();
        poolKey = baseComp != null ? baseComp.PoolKey : null;
    }

    private void OnIconLoaded(AsyncOperationHandle<Texture> handle)
    {
        if (handle.Status != AsyncOperationStatus.Succeeded)
        {
            Debug.LogError($"[스킬 버튼] 아이콘 로드 실패: {skillData?.Key}");
            return;
        }

        if (skillData != null && SkillCode == skillData.Code)
            rawimage.texture = handle.Result;
    }

    public void ClearSkill()
    {
        skillPrefab = null;
        skillData = null;
        poolKey = null;
        SkillCode = -1;
        owner = null;

        rawimage.texture = null;

        cooldownDuration = 0f;
        cooldownRemaining = 0f;
        if (cooldownMask != null)
            cooldownMask.fillAmount = 0f;
    }

    public void SetIcon(Texture texture)
    {
        rawimage.texture = texture;
    }

    public void TryUseSkill()
    {
        if (skillPrefab == null || skillTransform == null)
            return;

        if (IsOnCooldown)
            return;

        PlayerModel playerModel = owner != null ? owner : SkillManager.Instance.PlayerModel;
        if (playerModel == null)
        {
            Debug.LogError("[스킬 버튼] PlayerModel이 없습니다.");
            return;
        }

        if (skillData != null && skillData.MpCost > 0f)
        {
            if (!playerModel.TryConsumeMP(skillData.MpCost))
                return;
        }

        if (PoolManager.Instance == null)
        {
            Debug.LogError("[스킬 버튼] PoolManager가 없습니다.");
            return;
        }

        if (string.IsNullOrEmpty(poolKey))
        {
            Debug.LogError($"[스킬 버튼] poolKey가 비어 있습니다: {SlotCode}");
            return;
        }

        GameObject obj = PoolManager.Instance.GetObject(
            poolKey,
            skillTransform.position,
            Quaternion.identity
        );

        if (obj == null)
        {
            Debug.LogError($"[스킬 버튼] 풀에서 오브젝트를 가져오지 못했습니다: {poolKey}");
            return;
        }

        SkillBase skill = obj.GetComponent<SkillBase>();
        if (skill == null)
        {
            Debug.LogError("[스킬 버튼] SkillBase 컴포넌트가 없습니다.");
            return;
        }

        skill.SetOwner(playerModel);
        if (skillData != null)
            skill.ApplyData(skillData);

        Vector3 direction = -skillTransform.right;
        skill.ActivateSkill(direction);

        if (cooldownDuration > 0f)
        {
            cooldownRemaining = cooldownDuration;
            if (cooldownMask != null)
                cooldownMask.fillAmount = 1f;
        }
    }
}
