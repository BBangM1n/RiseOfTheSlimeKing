public enum InventoryItemCategory
{
    Weapon,
    Consumable,
    Etc
}
