[System.Serializable]
public class InventoryItem
{
    public Item item;
    public int count;

    public const int MAX_STACK = 99;

    public InventoryItem(Item item, int count = 1)
    {
        this.item = item;
        this.count = count;
    }

    public bool CanStack()
    {
        return item.Type == ItemKind.Consumable
            || item.Type == ItemKind.Material
            || item.Type == ItemKind.Etc;
    }

    public bool IsFull()
    {
        return count >= MAX_STACK;
    }
}