﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance { get; private set; }

    [Header("UI")]
    [SerializeField] private InventoryUI inventoryUI;

    [Header("Player Slots")]
    [SerializeField] private PlayerSlot[] playerSlots;

    [Header("Inventory Capacity")]
    [SerializeField] private int weaponSlotCount = 64;
    [SerializeField] private int consumableSlotCount = 64;
    [SerializeField] private int etcSlotCount = 64;

    private readonly Dictionary<InventoryItemCategory, List<InventoryItem>> inventory = new();

    public PlayerSlot[] PlayerSlots => playerSlots;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        foreach (InventoryItemCategory category in Enum.GetValues(typeof(InventoryItemCategory)))
        {
            inventory[category] = new List<InventoryItem>();
        }
    }

    private void Start()
    {
        if (inventoryUI != null)
            inventoryUI.OnChangeCategory += UpdateInventoryUI;
    }

    public void OnPickupItem(ItemDropData data)
    {
        if (data == null)
            return;

        if (data.type == DropItemType.Coin)
        {
            int amount = UnityEngine.Random.Range(data.minCoinAmount, data.maxCoinAmount + 1);
            int gold = amount * data.coinValuePerUnit;

            LogPupupManager.Instance.AddGold(gold);
            GameManager.Instance.goldUpdate(gold);
            return;
        }

        if (!ExcelReader.Instance.dicItem.TryGetValue(data.itemCode, out Item item))
        {
            Debug.LogError($"[인벤토리] 아이템 코드가 존재하지 않습니다: {data.itemCode}");
            return;
        }

        AddItem(item);

        switch (item.Type)
        {
            case ItemKind.Weapon:
                LogPupupManager.Instance.AddItem(item.Name);
                break;

            case ItemKind.Consumable:
                LogPupupManager.Instance.AddConsume(item.Name);
                ConsumableUI.Instance.Refresh();
                break;

            case ItemKind.Material:
            case ItemKind.Etc:
                LogPupupManager.Instance.AddMaterial(item.Name);
                break;
        }

        if (!string.IsNullOrEmpty(data.itemCode))
            QuestManager.Instance.CheckObjective("Collect", data.itemCode);
    }

    public void AddItem(Item item)
    {
        if (item == null)
            return;

        InventoryItemCategory category = ConvertCategory(item);

        bool stackable =
            item.Type == ItemKind.Consumable ||
            item.Type == ItemKind.Material ||
            item.Type == ItemKind.Etc;

        if (stackable)
        {
            InventoryItem exist = inventory[category]
                .Find(i => i.item.Code == item.Code && i.count < InventoryItem.MAX_STACK);

            if (exist != null)
            {
                exist.count++;
            }
            else
            {
                inventory[category].Add(new InventoryItem(item, 1));
            }
        }
        else
        {
            inventory[category].Add(new InventoryItem(item, 1));
        }

        UpdateInventoryUI(inventoryUI.CurrentCategory);
    }

    private InventoryItemCategory ConvertCategory(Item item)
    {
        return item.Type switch
        {
            ItemKind.Weapon => InventoryItemCategory.Weapon,
            ItemKind.Consumable => InventoryItemCategory.Consumable,
            ItemKind.Material => InventoryItemCategory.Etc,
            ItemKind.Etc => InventoryItemCategory.Etc,
            _ => InventoryItemCategory.Etc
        };
    }

    private void UpdateInventoryUI(InventoryItemCategory category)
    {
        if (inventoryUI == null)
            return;

        List<InventoryItem> items = inventory[category];
        Slot[] slots = inventoryUI.Slots;

        for (int i = 0; i < slots.Length; i++)
        {
            if (i < items.Count) slots[i].SetItem(items[i]);
            else slots[i].SetItem(null);
        }
    }

    public void SetUIState()
    {
        inventoryUI.StateUpdate();

        if (playerSlots == null)
            return;

        foreach (var slot in playerSlots)
            slot.Refresh();
    }

    public void RefreshInventoryUI()
    {
        UpdateInventoryUI(inventoryUI.CurrentCategory);
    }

    public void RefreshPlayerSlots()
    {
        if (playerSlots == null)
            return;

        foreach (var slot in playerSlots)
            slot.Refresh();
    }

    public void OpenInventory()
    {
        inventoryUI.Initialized();
        ConsumableUI.Instance.Refresh();
    }

    public void CloseInventory()
    {
        inventoryUI.CloseInventoryUI();
    }

    public void RemoveItem(InventoryItem item, int amount)
    {
        if (item == null)
            return;

        item.count -= amount;

        if (item.count <= 0)
        {
            InventoryItemCategory category = ConvertCategory(item.item);
            inventory[category].Remove(item);
        }

        RefreshInventoryUI();
        NotifyPickupRestored();
    }

    public void RemoveItemByCode(string itemCode, int amount)
    {
        foreach (var category in inventory.Values)
        {
            InventoryItem item = category.Find(i => i.item.Code == itemCode);
            if (item == null)
                continue;

            item.count -= amount;

            if (item.count <= 0)
                category.Remove(item);

            RefreshInventoryUI();
            RefreshPlayerSlots();
            NotifyPickupRestored();
            return;
        }

#if UNITY_EDITOR
        Debug.LogWarning($"[인벤토리] 제거하려는 아이템이 없습니다: {itemCode}");
#endif
    }

    public bool CanAddItem(Item item)
    {
        if (item == null)
            return false;

        InventoryItemCategory category = ConvertCategory(item);

        int maxSlot = GetMaxSlot(category);
        int currentCount = inventory[category].Count;

        bool stackable =
            item.Type == ItemKind.Consumable ||
            item.Type == ItemKind.Material ||
            item.Type == ItemKind.Etc;

        if (stackable)
        {
            InventoryItem exist = inventory[category]
                .Find(i => i.item.Code == item.Code && i.count < InventoryItem.MAX_STACK);

            if (exist != null)
                return true;
        }

        return currentCount < maxSlot;
    }

    private int GetMaxSlot(InventoryItemCategory category)
    {
        return category switch
        {
            InventoryItemCategory.Weapon => weaponSlotCount,
            InventoryItemCategory.Consumable => consumableSlotCount,
            InventoryItemCategory.Etc => etcSlotCount,
            _ => 0
        };
    }

    public bool CanPickup(ItemDropData data)
    {
        if (data == null)
            return false;

        if (data.type == DropItemType.Coin)
            return true;

        if (!ExcelReader.Instance.dicItem.TryGetValue(data.itemCode, out Item item))
            return false;

        return CanAddItem(item);
    }

    public void ShowInventoryFullLog(ItemDropData data)
    {
        if (data == null)
            return;

        if (!ExcelReader.Instance.dicItem.TryGetValue(data.itemCode, out Item item))
            return;

        InventoryItemCategory category = ConvertCategory(item);

        string message = category switch
        {
            InventoryItemCategory.Weapon => "무기 인벤토리가 가득 찼습니다.",
            InventoryItemCategory.Consumable => "소비 아이템 인벤토리가 가득 찼습니다.",
            InventoryItemCategory.Etc => "기타 아이템 인벤토리가 가득 찼습니다.",
            _ => "인벤토리가 가득 찼습니다."
        };

        LogPupupManager.Instance.AddLog(LogType.Item, message);
    }

    private void NotifyPickupRestored()
    {
        ItemPickup[] worldItems = FindObjectsOfType<ItemPickup>();

        foreach (var pickup in worldItems)
        {
            if (pickup == null || pickup.data == null)
                continue;

            if (CanPickup(pickup.data))
                pickup.RestorePickup();
        }
    }

    public void FillSaveData(SaveData data)
    {
        data.inventoryItems.Clear();

        foreach (InventoryItemCategory category in Enum.GetValues(typeof(InventoryItemCategory)))
        {
            List<InventoryItem> list = inventory[category];

            foreach (var invItem in list)
            {
                data.inventoryItems.Add(new InventoryItemSave
                {
                    category = category,
                    itemCode = invItem.item.Code,
                    count = invItem.count
                });
            }
        }

        data.equippedItems.Clear();

        foreach (EquipSlot slot in Enum.GetValues(typeof(EquipSlot)))
        {
            InventoryItem equipped = PlayerEquipmentManager.Instance.GetEquippedItem(slot);
            if (equipped == null)
                continue;

            data.equippedItems.Add(new EquippedItemSave
            {
                equipSlot = slot,
                itemCode = equipped.item.Code
            });
        }
    }

    public void ApplySaveData(SaveData data)
    {
        foreach (InventoryItemCategory category in Enum.GetValues(typeof(InventoryItemCategory)))
        {
            inventory[category].Clear();
        }

        foreach (var saved in data.inventoryItems)
        {
            if (!ExcelReader.Instance.dicItem.TryGetValue(saved.itemCode, out Item itemData))
            {
                Debug.LogError($"[세이브 로드] 아이템 코드가 존재하지 않습니다: {saved.itemCode}");
                continue;
            }

            for (int i = 0; i < saved.count; i++)
            {
                AddItem(itemData);
            }
        }

        foreach (EquipSlot slot in Enum.GetValues(typeof(EquipSlot)))
        {
            PlayerEquipmentManager.Instance.Unequip(slot);
        }

        foreach (var eq in data.equippedItems)
        {
            if (!ExcelReader.Instance.dicItem.TryGetValue(eq.itemCode, out Item itemData))
            {
                Debug.LogError($"[세이브 로드] 장착 아이템 코드가 존재하지 않습니다: {eq.itemCode}");
                continue;
            }

            InventoryItemCategory category = ConvertCategory(itemData);

            InventoryItem invItem = inventory[category]
                .Find(i => i.item.Code == eq.itemCode);

            if (invItem == null)
            {
#if UNITY_EDITOR
                Debug.LogWarning($"[세이브 로드] 장착 아이템을 인벤토리에서 찾을 수 없습니다: {eq.itemCode}");
#endif
                continue;
            }

            PlayerEquipmentManager.Instance.Equip(invItem);
        }

        RefreshInventoryUI();
        RefreshPlayerSlots();
    }
}
