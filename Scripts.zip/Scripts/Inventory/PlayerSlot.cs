﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerSlot : MonoBehaviour
{
    [Header("Equip Info")]
    [SerializeField] private EquipSlot equipSlot;

    [Header("UI")]
    [SerializeField] private Image icon;
    [SerializeField] private TextMeshProUGUI slotText;
    [SerializeField] private Button button;

    private InventoryItem equippedInventoryItem;

    private void Awake()
    {
        button.onClick.AddListener(OnClickSlot);
    }

    private void OnEnable()
    {
        Refresh();
    }

    public void Refresh()
    {
        InventoryItem item = PlayerEquipmentManager.Instance.GetEquippedItem(equipSlot);

        if (item == null)
        {
            Clear();
            return;
        }

        equippedInventoryItem = item;

        icon.enabled = false;

        ItemIconCache.Instance.Load(item.item.Key, sprite =>
        {
            if (equippedInventoryItem != item)
                return;

            icon.sprite = sprite;
            icon.enabled = true;
        });

        if (slotText != null)
            slotText.text = item.item.Name;
    }

    private void OnClickSlot()
    {
        if (equippedInventoryItem == null)
            return;

        ItemInfoUI.Instance.Open(equippedInventoryItem, icon.sprite);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    private void Clear()
    {
        equippedInventoryItem = null;

        icon.sprite = null;
        icon.enabled = false;

        if (slotText != null)
            slotText.text = equipSlot.ToString();
    }
}
