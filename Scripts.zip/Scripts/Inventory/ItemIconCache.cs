﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

public class ItemIconCache : MonoBehaviour
{
    public static ItemIconCache Instance { get; private set; }

    private readonly Dictionary<string, Sprite> cache = new();
    private readonly Dictionary<string, AsyncOperationHandle<Sprite>> handles = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void Load(string key, Action<Sprite> onLoaded)
    {
        if (string.IsNullOrEmpty(key))
            return;

        if (cache.TryGetValue(key, out var sprite))
        {
            onLoaded?.Invoke(sprite);
            return;
        }

        if (handles.ContainsKey(key))
            return;

        var handle = Addressables.LoadAssetAsync<Sprite>(key);
        handles[key] = handle;

        handle.Completed += h =>
        {
            if (h.Status == AsyncOperationStatus.Succeeded)
            {
                cache[key] = h.Result;
                onLoaded?.Invoke(h.Result);
            }
            else
            {
                Debug.LogError($"[아이콘 로드] 아이콘을 불러오지 못했습니다: {key}");
            }
        };
    }

    public void Clear()
    {
        foreach (var h in handles.Values)
            Addressables.Release(h);

        cache.Clear();
        handles.Clear();
    }
}
