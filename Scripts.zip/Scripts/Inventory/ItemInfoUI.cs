﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ItemInfoUI : MonoBehaviour
{
    public static ItemInfoUI Instance { get; private set; }

    [Header("Root")]
    [SerializeField] private GameObject root;

    [Header("Icon")]
    [SerializeField] private Image iconImage;

    [Header("Texts")]
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private TextMeshProUGUI explainText;
    [SerializeField] private TextMeshProUGUI sellPriceText;

    [Header("Stat Texts")]
    [SerializeField] private TextMeshProUGUI adText;
    [SerializeField] private TextMeshProUGUI deText;
    [SerializeField] private TextMeshProUGUI hpText;
    [SerializeField] private TextMeshProUGUI mpText;

    [Header("Buttons")]
    [SerializeField] private Button equipButton;
    [SerializeField] private Button unequipButton;
    [SerializeField] private Button sellButton;
    [SerializeField] private Button closeButton;

    private InventoryItem currentItem;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        equipButton.onClick.AddListener(OnClickEquip);
        unequipButton.onClick.AddListener(OnClickUnequip);
        sellButton.onClick.AddListener(OnClickSell);
        closeButton.onClick.AddListener(Close);

        root.SetActive(false);
    }

    public void Open(InventoryItem inventoryItem, Sprite icon)
    {
        currentItem = inventoryItem;

        nameText.text = inventoryItem.item.Name;
        explainText.text = inventoryItem.item.Explain;

        iconImage.sprite = icon;
        iconImage.enabled = icon != null;

        UpdateStatTexts(inventoryItem.item);
        UpdateSellPrice(inventoryItem);
        UpdateButtons();

        root.SetActive(true);
    }

    private void UpdateStatTexts(Item item)
    {
        int ad = 0, de = 0, hp = 0, mp = 0;

        if (item is WeaponItem w)
        {
            ad = w.AttackPower;
            de = w.DefensePower;
            hp = w.HP;
            mp = w.MP;
        }

        adText.text = ad > 0 ? $"+{ad}" : "0";
        deText.text = de > 0 ? $"+{de}" : "0";
        hpText.text = hp > 0 ? $"+{hp}" : "0";
        mpText.text = mp > 0 ? $"+{mp}" : "0";
    }

    private void UpdateSellPrice(InventoryItem inventoryItem)
    {
        int price = Mathf.FloorToInt(inventoryItem.item.Price * 0.5f);
        sellPriceText.text = $"판매가 : {price} G";
    }

    private void OnClickEquip()
    {
        if (currentItem == null)
            return;

        bool success = PlayerEquipmentManager.Instance.Equip(currentItem);
        if (!success)
            return;

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);

        UpdateButtons();
        SaveManager.Instance.SaveGame();
    }

    private void OnClickUnequip()
    {
        if (currentItem == null)
            return;

        Item item = currentItem.item;

        if (item is ConsumableItem consumable)
        {
            if (consumable.HealHP > 0)
                PlayerEquipmentManager.Instance.UnequipHP();
            else if (consumable.HealMP > 0)
                PlayerEquipmentManager.Instance.UnequipMP();
        }
        else
        {
            PlayerEquipmentManager.Instance.Unequip(item.EquipSlot);
        }

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);

        UpdateButtons();
        SaveManager.Instance.SaveGame();
    }

    private void OnClickSell()
    {
        if (currentItem == null)
            return;

        if (PlayerEquipmentManager.Instance.IsEquipped(currentItem))
            return;

        Item item = currentItem.item;
        int sellPrice = Mathf.FloorToInt(item.Price * 0.5f);

        GameManager.Instance.goldUpdate(sellPrice);
        LogPupupManager.Instance.AddGold(sellPrice);

        InventoryManager.Instance.RemoveItem(currentItem, 1);

        AudioManager.Instance?.PlaySfx(SfxType.Buy);

        Close();
        SaveManager.Instance.SaveGame();
    }

    private void UpdateButtons()
    {
        if (currentItem == null)
            return;

        Item item = currentItem.item;

        if (item is ConsumableItem)
        {
            bool isConsumEquipped = PlayerEquipmentManager.Instance.IsEquipped(currentItem);

            equipButton.interactable = !isConsumEquipped;
            unequipButton.interactable = isConsumEquipped;
            sellButton.interactable = !isConsumEquipped;
            return;
        }

        if (item.Type == ItemKind.Material)
        {
            equipButton.interactable = false;
            unequipButton.interactable = false;
            sellButton.interactable = true;
            return;
        }

        bool isEquipped = PlayerEquipmentManager.Instance.IsEquipped(currentItem);

        equipButton.interactable = !isEquipped;
        unequipButton.interactable = isEquipped;
        sellButton.interactable = !isEquipped;
    }

    public void Close()
    {
        currentItem = null;
        root.SetActive(false);
    }
}
