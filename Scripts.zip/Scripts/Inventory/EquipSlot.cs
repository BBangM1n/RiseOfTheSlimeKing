public enum EquipSlot
{
    Head,
    Body,
    Weapon,
    HP,
    MP,
    Etc
}