using UnityEngine;
using UnityEngine.UI;

public class ExplanScreen : MonoBehaviour
{
    [SerializeField] private RawImage image;
    [SerializeField] private Button close;
    [SerializeField] private Text nameText;
    [SerializeField] private Text explanText;
    [SerializeField] private Text mpText;
    [SerializeField] private Text coolTimeText;

    [SerializeField] private Transform prefabParent;
    private SkillUIPrefab[] skillUIPrefabs;

    public void Init()
    {
        skillUIPrefabs = prefabParent.GetComponentsInChildren<SkillUIPrefab>(true);

        foreach (var prefab in skillUIPrefabs)
            prefab.info += OpenExplanScreen;

        close.onClick.AddListener(CloseButtonClick);
        gameObject.SetActive(false);
    }

    private void OnDestroy()
    {
        if (skillUIPrefabs == null) return;

        foreach (var prefab in skillUIPrefabs)
            prefab.info -= OpenExplanScreen;
    }

    private void OpenExplanScreen(string name, string explan, Texture texture, string mp, string cooltime)
    {
        image.texture = texture;
        nameText.text = name;
        explanText.text = explan;
        mpText.text = "MP : " + mp;
        coolTimeText.text = "��Ÿ�� : " + cooltime;

        gameObject.SetActive(true);
    }

    private void CloseButtonClick()
    {
        gameObject.SetActive(false);
        nameText.text = "";
        explanText.text = "";
        image.texture = null;
    }
}
