﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour
{
    public InventoryItemCategory inventoryItemCategory;

    [SerializeField] private Image icon;
    [SerializeField] private TextMeshProUGUI countText;
    [SerializeField] private Button button;
    [SerializeField] private GameObject equippedMark;

    private InventoryItem currentItem;
    private string currentKey;

    private void Awake()
    {
        button.onClick.AddListener(OnClickSlot);
    }

    public void SetItem(InventoryItem item)
    {
        currentItem = item;

        if (item == null)
        {
            icon.enabled = false;
            icon.sprite = null;

            countText.gameObject.SetActive(false);
            equippedMark.SetActive(false);

            currentKey = null;
            return;
        }

        currentKey = item.item.Key;

        icon.sprite = null;
        icon.enabled = false;

        UpdateCount(item);
        UpdateEquipMark();

        ItemIconCache.Instance.Load(currentKey, sprite =>
        {
            if (currentItem != null && currentItem.item.Key == currentKey)
            {
                icon.sprite = sprite;
                icon.enabled = true;
            }
        });
    }

    private void UpdateCount(InventoryItem item)
    {
        if (item.count > 1)
        {
            countText.gameObject.SetActive(true);
            countText.text = item.count.ToString();
        }
        else
        {
            countText.gameObject.SetActive(false);
        }
    }

    private void UpdateEquipMark()
    {
        bool isEquipped =
            currentItem != null &&
            PlayerEquipmentManager.Instance.IsEquipped(currentItem);

        equippedMark.SetActive(isEquipped);
    }

    private void OnClickSlot()
    {
        if (currentItem == null)
            return;

        ItemInfoUI.Instance.Open(currentItem, icon.sprite);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }
}
