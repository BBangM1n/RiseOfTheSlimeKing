using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class InventoryUI : MonoBehaviour
{
    public InventoryItemCategory CurrentCategory { get; private set; }

    [SerializeField] private PlayerModel playerModel;

    [Header("Buttons")]
    [SerializeField] private Button weaponButton;
    [SerializeField] private Button consumButton;
    [SerializeField] private Button etcButton;

    [Header("Texts")]
    [SerializeField] private TextMeshProUGUI hpText;
    [SerializeField] private TextMeshProUGUI mpText;
    [SerializeField] private TextMeshProUGUI adText;
    [SerializeField] private TextMeshProUGUI deText;

    [Header("Slots")]
    [SerializeField] private Slot[] slots;

    public Slot[] Slots => slots;

    public event Action<InventoryItemCategory> OnChangeCategory;

    private void Awake()
    {
        weaponButton.onClick.AddListener(() =>
        {
            SetCategory(InventoryItemCategory.Weapon);
            SetButtonState(weaponButton);
        });

        consumButton.onClick.AddListener(() =>
        {
            SetCategory(InventoryItemCategory.Consumable);
            SetButtonState(consumButton);
        });

        etcButton.onClick.AddListener(() =>
        {
            SetCategory(InventoryItemCategory.Etc);
            SetButtonState(etcButton);
        });
    }

    public void Initialized()
    {
        SetCategory(InventoryItemCategory.Weapon);
        SetButtonState(weaponButton);
        StateUpdate();
        gameObject.SetActive(true);
    }

    public void CloseInventoryUI()
    {
        gameObject.SetActive(false);
    }

    private void SetCategory(InventoryItemCategory type)
    {
        CurrentCategory = type;

        foreach (var slot in slots)
            slot.inventoryItemCategory = type;

        OnChangeCategory?.Invoke(type);
    }

    private void SetButtonState(Button selected)
    {
        weaponButton.interactable = true;
        consumButton.interactable = true;
        etcButton.interactable = true;

        selected.interactable = false;

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    public void StateUpdate()
    {
        hpText.text = "ü�� " + (int)playerModel.MaxHP;
        mpText.text = "���� " + (int)playerModel.MaxMP;
        adText.text = "���� " + (int)playerModel.Damage;
        deText.text = "��� " + (int)playerModel.Defense;
    }
}
