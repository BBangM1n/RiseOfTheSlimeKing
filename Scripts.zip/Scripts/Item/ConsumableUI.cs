﻿using System.Collections;
using UnityEngine;

public class ConsumableUI : MonoBehaviour
{
    public static ConsumableUI Instance;

    [SerializeField] private ConsumableSlotUI hpSlot;
    [SerializeField] private ConsumableSlotUI mpSlot;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        StartCoroutine(RefreshNextFrame());
    }

    private IEnumerator RefreshNextFrame()
    {
        yield return null;
        Refresh();
    }

    public void Refresh()
    {
        var equip = PlayerEquipmentManager.Instance;

        if (equip.equippedHPItem != null)
            hpSlot.SetItem(equip.equippedHPItem);
        else
            hpSlot.Clear();

        if (equip.equippedMPItem != null)
            mpSlot.SetItem(equip.equippedMPItem);
        else
            mpSlot.Clear();
    }
}
