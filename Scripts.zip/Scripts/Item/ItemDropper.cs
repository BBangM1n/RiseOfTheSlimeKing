﻿using UnityEngine;

public class ItemDropper : MonoBehaviour
{
    [Header("아이템 드롭 설정")]
    public ItemDropData[] items;

    public void DropItems()
    {
        if (items == null || items.Length == 0)
            return;

        foreach (var data in items)
        {
            if (!string.IsNullOrEmpty(data.questCode) &&
                data.questCode != GameManager.Instance.CurrentQuestCode)
                continue;

            if (Random.value > data.dropChance)
                continue;

            int count = Random.Range(data.minCount, data.maxCount + 1);
            for (int i = 0; i < count; i++)
            {
                SpawnItem(data);
            }
        }
    }

    private void SpawnItem(ItemDropData data)
    {
        if (PoolManager.Instance == null)
        {
            Debug.LogError("[아이템 드롭] PoolManager가 존재하지 않습니다.");
            return;
        }

        if (string.IsNullOrEmpty(data.poolKey))
        {
            Debug.LogError($"[아이템 드롭] poolKey가 비어 있습니다. itemCode={data.itemCode}");
            return;
        }

        Vector3 spawnPos = transform.position +
                           new Vector3(Random.Range(-0.3f, 0.3f), 0.2f, 0f);

        GameObject item = PoolManager.Instance.GetObject(
            data.poolKey,
            spawnPos,
            Quaternion.identity
        );

        if (item == null)
        {
            Debug.LogError($"[아이템 드롭] 풀에서 오브젝트를 가져오지 못했습니다. key={data.poolKey}");
            return;
        }

        ItemPickup pickup = item.GetComponent<ItemPickup>();
        if (pickup != null)
        {
            pickup.data = data;
            pickup.poolKey = data.poolKey;
            pickup.RestorePickup();
        }

        Rigidbody2D rb = item.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.velocity = Vector2.zero;
            rb.angularVelocity = 0f;

            rb.bodyType = RigidbodyType2D.Dynamic;
            rb.simulated = true;

            rb.AddForce(
                new Vector2(Random.Range(-2f, 2f), Random.Range(3f, 5f)),
                ForceMode2D.Impulse
            );
            rb.AddTorque(Random.Range(-5f, 5f), ForceMode2D.Impulse);
        }
    }
}
