public class ConsumableItem : Item
{
    public int HealHP;
    public int HealMP;
}
