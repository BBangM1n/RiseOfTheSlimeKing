﻿using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    [HideInInspector] public ItemDropData data;
    [HideInInspector] public string poolKey;

    private Collider2D pickupTrigger;
    private Collider2D bodyCollider;
    private Collider2D ignoredPlayerCollider;

    private void Awake()
    {
        bodyCollider = GetComponent<Collider2D>();

        foreach (var col in GetComponentsInChildren<Collider2D>(true))
        {
            if (col.isTrigger)
            {
                pickupTrigger = col;
                break;
            }
        }
    }

    private void OnDisable()
    {
        RestorePickup();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player"))
            return;

        if (InventoryManager.Instance == null)
            return;

        if (!InventoryManager.Instance.CanPickup(data))
        {
            InventoryManager.Instance.ShowInventoryFullLog(data);
            SetPickupDisabled(other);
            return;
        }

        InventoryManager.Instance.OnPickupItem(data);
        AudioManager.Instance?.PlaySfx(SfxType.Get);

        if (!string.IsNullOrEmpty(poolKey) && PoolManager.Instance != null)
        {
            SaveManager.Instance.SaveGame();
            PoolManager.Instance.ReleaseObject(poolKey, gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void SetPickupDisabled(Collider2D playerCol)
    {
        if (pickupTrigger != null)
            pickupTrigger.enabled = false;

        if (bodyCollider != null)
            Physics2D.IgnoreCollision(bodyCollider, playerCol, true);

        ignoredPlayerCollider = playerCol;
    }

    public void RestorePickup()
    {
        if (pickupTrigger != null)
            pickupTrigger.enabled = true;

        if (bodyCollider != null && ignoredPlayerCollider != null)
            Physics2D.IgnoreCollision(bodyCollider, ignoredPlayerCollider, false);

        ignoredPlayerCollider = null;
    }
}
