public class WeaponItem : Item
{
    public int AttackPower;
    public int DefensePower;
    public int HP;
    public int MP;
}
