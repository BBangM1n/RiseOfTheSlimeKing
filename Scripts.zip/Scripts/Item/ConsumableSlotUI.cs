﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ConsumableSlotUI : MonoBehaviour
{
    [SerializeField] private Image icon;
    [SerializeField] private TextMeshProUGUI countText;

    private InventoryItem currentItem;

    public void SetItem(InventoryItem item)
    {
        currentItem = item;

        if (item == null || item.count <= 0)
        {
            Clear();
            return;
        }

        icon.enabled = false;

        ItemIconCache.Instance.Load(item.item.Key, sprite =>
        {
            if (currentItem != item) return;
            icon.sprite = sprite;
            icon.enabled = true;
        });

        countText.gameObject.SetActive(true);
        countText.text = item.count.ToString();
    }

    public void Clear()
    {
        currentItem = null;
        icon.sprite = null;
        icon.enabled = false;
        countText.gameObject.SetActive(false);
    }
}
