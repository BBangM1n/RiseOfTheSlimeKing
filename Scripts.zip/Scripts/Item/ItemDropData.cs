using UnityEngine;

public enum DropItemType
{
    Weapon,
    Consumable,
    Material,
    Coin
}

[System.Serializable]
public class ItemDropData
{
    [Header("������ �ĺ�")]
    public string itemCode;

    [Header("Ǯ Ű")]
    public string poolKey;

    public DropItemType type;

    [Header("Ȯ�� (0~1)")]
    [Range(0f, 1f)]
    public float dropChance = 1f;

    [Header("���� �ɼ�")]
    public int minCoinAmount = 1;
    public int maxCoinAmount = 1;
    public int coinValuePerUnit;

    [Header("��� ����")]
    public int minCount = 1;
    public int maxCount = 1;

    [Header("����Ʈ ����")]
    public string questCode = "";
}
