public class Item
{
    public string Code;
    public string Name;
    public string Key;
    public string Explain;
    public ItemKind Type;
    public int Price;

    public EquipSlot EquipSlot;
}