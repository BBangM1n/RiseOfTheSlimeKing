﻿using System.Collections;
using UnityEngine;

public class MainSceneInitializer : MonoBehaviour
{
    [SerializeField] private PlayerController player;

    private IEnumerator Start()
    {
        yield return WaitForGameDataReady();

        if (SaveManager.Instance == null)
            yield break;

        bool hasSave = SaveManager.Instance.ShouldLoadOnMain && SaveManager.Instance.HasSaveData(SaveManager.Instance.CurrentSlotIndex);

        if (hasSave)
        {
            SaveManager.Instance.LoadGame();

            yield return null;

            if (InventoryManager.Instance != null)
            {
                InventoryManager.Instance.RefreshInventoryUI();
                InventoryManager.Instance.RefreshPlayerSlots();
            }

            if (SkillManager.Instance != null)
            {
                SkillManager.Instance.UpdateAllSkillUILocks();
                SkillManager.Instance.RefreshSlotIcons();
            }

            if (QuestManager.Instance != null)
                QuestManager.Instance.RestoreCurrentQuestFromGame();

            if (player != null)
            {
                player.SyncUI();
            }

            StartCoroutine(DelayedConsumableRefresh(0.5f));
        }
    }

    private IEnumerator DelayedConsumableRefresh(float delay)
    {
        yield return new WaitForSeconds(delay);

        if (ConsumableUI.Instance != null)
            ConsumableUI.Instance.Refresh();
    }

    private IEnumerator WaitForGameDataReady()
    {
        if (GameDataManager.Instance == null)
            yield break;

        float timeout = 15f;
        float t = 0f;

        while (t < timeout)
        {
            if (GameDataManager.Instance.IsReady)
                yield break;

            t += Time.unscaledDeltaTime;
            yield return null;
        }

        Debug.LogWarning("[초기화] GameDataManager.IsReady 대기 시간 초과. (Addressables/DB 로드 확인 필요)");
    }
}
