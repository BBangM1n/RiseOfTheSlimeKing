using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;

public class LoadNameManager : MonoBehaviour
{
    public static LoadNameManager Instance { get; private set; }

    private Dictionary<string, string> npcNames = new();
    private Dictionary<string, string> itemNames = new();
    private Dictionary<string, string> monsterNames = new();

    private bool isLoaded = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public async UniTask LoadAll()
    {
        if (isLoaded)
            return;

        await LoadNPC();
        await LoadItem();
        await LoadMonster();

        isLoaded = true;
        Debug.Log("[�̸� �δ�] ��� �̸� ������ �ε� �Ϸ�");
    }

    private async UniTask LoadNPC()
    {
        npcNames.Clear();
        var data = await QuestCSVLoader.LoadCSV("Data/NPC_info");

        foreach (var row in data)
        {
            if (!row.ContainsKey("ID"))
                continue;

            string id = row["ID"];
            string kr = row.TryGetValue("KR", out var name) ? name : id;
            npcNames[id] = kr;
        }
    }

    private async UniTask LoadItem()
    {
        itemNames.Clear();
        var data = await QuestCSVLoader.LoadCSV("Data/Item_info");

        foreach (var row in data)
        {
            if (!row.ContainsKey("ID"))
                continue;

            string id = row["ID"];
            string kr = row.TryGetValue("KR", out var name) ? name : id;
            itemNames[id] = kr;
        }
    }

    private async UniTask LoadMonster()
    {
        monsterNames.Clear();
        var data = await QuestCSVLoader.LoadCSV("Data/Monster_info");

        foreach (var row in data)
        {
            if (!row.ContainsKey("ID"))
                continue;

            string id = row["ID"];
            string kr = row.TryGetValue("KR", out var name) ? name : id;
            monsterNames[id] = kr;
        }
    }

    public string GetKRName(string id)
    {
        if (npcNames.TryGetValue(id, out var npc)) return npc;
        if (itemNames.TryGetValue(id, out var item)) return item;
        if (monsterNames.TryGetValue(id, out var monster)) return monster;

        return id;
    }
}
