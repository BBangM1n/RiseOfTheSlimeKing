﻿public enum QuestState
{
    NotAccepted,
    InProgress,
    ReadyToClear,
    Completed
}