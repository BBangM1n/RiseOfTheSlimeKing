using System.Collections.Generic;

[System.Serializable]
public class QuestReward
{
    public string RewardID;
    public int Gold;
    public int Exp;
    public List<RewardItem> Items = new();
}

[System.Serializable]
public class RewardItem
{
    public string ItemID;
    public int Count;
}
