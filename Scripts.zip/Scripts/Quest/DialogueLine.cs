public class DialogueLine
{
    public string DialogueID; 
    public int Order;
    public string Speaker;
    public string Text;
    public string NextDialogueID;
} 