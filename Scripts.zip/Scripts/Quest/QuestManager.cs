﻿using System.Collections.Generic;
using UnityEngine;

public class QuestManager : MonoBehaviour
{
    public static QuestManager Instance;

    public QuestDatabase questDB;
    public RewardDatabase rewardDB;

    public DialogueDatabase dialogueDB;
    public QuestUI questUI;

    private Quest currentQuest;
    private List<DialogueLine> currentDialogue;
    private int dialogueIndex;

    private bool isClearDialoguePlaying = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void StartQuest()
    {
        if (GameManager.Instance == null)
        {
            Debug.LogError("[QuestManager] GameManager.Instance is null");
            return;
        }

        string questCode = GameManager.Instance.CurrentQuestCode;

        if (string.IsNullOrEmpty(questCode))
        {
            Debug.LogError("[QuestManager] CurrentQuestCode is EMPTY. 퀘스트를 시작할 코드가 없음");
            return;
        }

        if (questDB == null)
        {
            Debug.LogError("[QuestManager] questDB is null (Inspector 연결 확인)");
            return;
        }

        if (!questDB.Quests.TryGetValue(questCode, out currentQuest))
        {
            Debug.LogError($"[QuestManager] questDB에 없는 코드: {questCode}");
            return;
        }

        Debug.Log($"[QuestManager] StartQuest code={questCode}, StartDialogueID={currentQuest.StartDialogueID}");


        currentQuest = questDB.Quests[questCode];
        GameManager.Instance.SetQuestState(questCode, QuestState.InProgress);

        GameManager.Instance.isQuesting = true;

        PlayDialogue(currentQuest.StartDialogueID);
        ChatManager.Instance.ChatOn();

        Debug.Log($"퀘스트 시작: {currentQuest.Title}");
    }

    public void PlayDialogue(string dialogueID)
    {
        if (dialogueDB == null)
        {
            Debug.LogError("[QuestManager] dialogueDB is null (Inspector 연결 확인)");
            return;
        }

        if (string.IsNullOrEmpty(dialogueID))
        {
            Debug.LogError("[QuestManager] dialogueID is EMPTY (Quest 데이터 확인)");
            return;
        }

        currentDialogue = dialogueDB.GetDialogue(dialogueID);

        if (currentDialogue == null || currentDialogue.Count == 0)
        {
            Debug.LogError($"[QuestManager] Dialogue 없음 or 비어있음: {dialogueID}");
            ChatManager.Instance.ChatOff();
            return;
        }

        dialogueIndex = 0;
        ShowCurrentDialogue();
    }

    void ShowCurrentDialogue()
    {

        if (currentDialogue == null)
        {
            Debug.LogError("❌ currentDialogue is null");
            ChatManager.Instance.ChatOff();
            return;
        }


        if (dialogueIndex >= currentDialogue.Count)
        {
            ChatManager.Instance.ChatOff();

            OnDialogueFinished();

            return;
        }

        DialogueLine line = currentDialogue[dialogueIndex];
        ChatManager.Instance.SetSpeaker(line.Speaker);
        ChatManager.Instance.SetDialogue(line.Text);
    }

    public void NextDialogue()
    {
        dialogueIndex++;
        if (isClearDialoguePlaying)
        {
            isClearDialoguePlaying = false;

            ConsumeQuestItems(currentQuest);

            GameManager.Instance.SetQuestState(
                currentQuest.QuestID,
                QuestState.Completed
            );

            GiveQuestReward(currentQuest);

            GameManager.Instance.QuestClear(currentQuest.NextQuestCode);
            GameManager.Instance.isQuesting = false;

            currentQuest = null;
            questUI.ShowQuest(null);
            SaveManager.Instance.SaveGame();
        }

        ShowCurrentDialogue();

        AudioManager.Instance?.PlaySfx(SfxType.OpenShop);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    public void CheckObjective(string type, string targetID)
    {
        if (currentQuest == null) return;

        foreach (var obj in currentQuest.Objectives)
        {
            if (obj.Type == type && obj.TargetID == targetID)
            {
                if (obj.Current < obj.Total)
                {
                    obj.Current++;
                    questUI.ShowQuest(currentQuest);
                    SaveManager.Instance.SaveGame();
                }

                if (IsQuestCompleted())
                {
                    GameManager.Instance.SetQuestState(
                        currentQuest.QuestID,
                        QuestState.ReadyToClear
                    );
                }
            }
        }
    }

    bool IsQuestCompleted()
    {
        foreach (var obj in currentQuest.Objectives)
        {
            if (obj.Current < obj.Total)
                return false;
        }
        return true;
    }

    public void CompleteQuest()
    {
        isClearDialoguePlaying = true;
        PlayDialogue(currentQuest.ClearDialogueID);
        ChatManager.Instance.ChatOn();
        SaveManager.Instance.SaveGame();
    }

    public bool IsTalkTarget(string npcID)
    {
        if (currentQuest == null) return false;

        foreach (var obj in currentQuest.Objectives)
        {
            if (obj.Type == "Talk" && obj.TargetID == npcID)
                return true;
        }
        return false;
    }

    void OnDialogueFinished()
    {
        if (currentQuest == null) return;

        questUI.ShowQuest(currentQuest);
    }

    void GiveQuestReward(Quest quest)
    {
        if (string.IsNullOrEmpty(quest.RewardID)) return;

        if (!rewardDB.Rewards.TryGetValue(quest.RewardID, out QuestReward reward))
        {
            Debug.LogError($"[QuestManager] RewardID 없음: {quest.RewardID}");
            return;
        }

        if (reward.Gold > 0)
        {
            GameManager.Instance.goldUpdate(reward.Gold);
            LogPupupManager.Instance.AddGold(reward.Gold);
            Debug.Log($"골드 획득: {reward.Gold}");
        }

        if (reward.Exp > 0)
        {
            ExpEvent.OnAddExp?.Invoke(reward.Exp);
            LogPupupManager.Instance.AddExp(reward.Exp);
            Debug.Log($"경험치 획득: {reward.Exp}");
        }

        foreach (var rewardItem in reward.Items)
        {
            string itemCode = rewardItem.ItemID;
            int count = Mathf.Max(1, rewardItem.Count);

            if (!ExcelReader.Instance.dicItem.TryGetValue(itemCode, out Item itemData))
            {
                Debug.LogError($"[QuestManager] 보상 아이템 코드 없음: {itemCode}");
                continue;
            }

            for (int i = 0; i < count; i++)
            {
                if (!InventoryManager.Instance.CanAddItem(itemData))
                {
                    Debug.LogWarning($"[QuestManager] 인벤토리 가득 - 아이템 보상 일부 지급 실패: {itemData.Name}");
                    break;
                }

                InventoryManager.Instance.AddItem(itemData);
            }

            switch (itemData.Type)
            {
                case ItemKind.Weapon:
                    LogPupupManager.Instance.AddItem($"{itemData.Name} x{count}");
                    break;

                case ItemKind.Consumable:
                    LogPupupManager.Instance.AddConsume($"{itemData.Name} x{count}");
                    break;

                case ItemKind.Material:
                case ItemKind.Etc:
                    LogPupupManager.Instance.AddMaterial($"{itemData.Name} x{count}");
                    break;
            }

            Debug.Log($"퀘스트 아이템 보상: {itemData.Name} x{count}");
        }

        Debug.Log($"퀘스트 보상 지급 완료: {quest.RewardID}");
    }

    void ConsumeQuestItems(Quest quest)
    {
        foreach (var obj in quest.Objectives)
        {
            if (obj.Type == "Collect")
            {
                InventoryManager.Instance.RemoveItemByCode(
                    obj.TargetID,
                    obj.Total
                );

                Debug.Log($"퀘스트 재료 소모: {obj.TargetID} x{obj.Total}");
            }
        }
    }

    public void RestoreCurrentQuestFromGame()
    {
        currentQuest = null;

        string questCode = GameManager.Instance.CurrentQuestCode;

        if (string.IsNullOrEmpty(questCode))
        {
            questUI.ShowQuest(null);
            return;
        }

        if (!questDB.Quests.TryGetValue(questCode, out Quest quest))
        {
            Debug.LogError($"[QuestManager] 퀘스트 코드 없음: {questCode}");
            questUI.ShowQuest(null);
            return;
        }

        QuestState state = GameManager.Instance.GetQuestState(questCode);

        if (state == QuestState.InProgress || state == QuestState.ReadyToClear)
        {
            currentQuest = quest;
            GameManager.Instance.isQuesting = true;
            questUI.ShowQuest(currentQuest);
        }
        else
        {
            questUI.ShowQuest(null);
            GameManager.Instance.isQuesting = false;
        }
    }
    public void FillSaveData(SaveData data)
    {
        if (currentQuest == null)
            return;

        var progress = new QuestProgressSave();

        progress.questCode = GameManager.Instance.CurrentQuestCode;

        foreach (var obj in currentQuest.Objectives)
        {
            progress.objectiveCurrents.Add(obj.Current);
        }

        data.questProgresses.Add(progress);
    }

    public void ApplySaveData(SaveData data)
    {
        currentQuest = null;

        string questCode = GameManager.Instance.CurrentQuestCode;

        if (string.IsNullOrEmpty(questCode))
        {
            questUI.ShowQuest(null);
            GameManager.Instance.isQuesting = false;
            return;
        }

        if (!questDB.Quests.TryGetValue(questCode, out Quest quest))
        {
            Debug.LogError($"[QuestManager] 퀘스트 코드 없음: {questCode}");
            questUI.ShowQuest(null);
            GameManager.Instance.isQuesting = false;
            return;
        }

        QuestProgressSave saved = null;
        if (data.questProgresses != null)
        {
            saved = data.questProgresses.Find(p => p.questCode == questCode);
        }

        if (saved != null)
        {
            int count = Mathf.Min(quest.Objectives.Count, saved.objectiveCurrents.Count);
            for (int i = 0; i < count; i++)
            {
                quest.Objectives[i].Current =
                    Mathf.Clamp(saved.objectiveCurrents[i], 0, quest.Objectives[i].Total);
            }
        }

        currentQuest = quest;

        QuestState state = GameManager.Instance.GetQuestState(questCode);

        if (state == QuestState.InProgress || state == QuestState.ReadyToClear)
        {
            GameManager.Instance.isQuesting = true;
            questUI.ShowQuest(currentQuest);
        }
        else
        {
            questUI.ShowQuest(null);
            GameManager.Instance.isQuesting = false;
        }
    }

    public bool HasTalkObjective()
    {
        if (currentQuest == null) return false;
        foreach (var obj in currentQuest.Objectives)
            if (obj.Type == "Talk") return true;
        return false;
    }
}
