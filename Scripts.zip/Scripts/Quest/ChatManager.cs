using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ChatManager : MonoBehaviour
{
    public static ChatManager Instance;

    public GameObject chatObject;
    public Button nextButton;

    public TextMeshProUGUI speakerText;
    public TextMeshProUGUI dialogueText;

    public bool IsUIBlockingInput = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        nextButton.onClick.AddListener(OnNextButtonClicked);
    }

    public void SetSpeaker(string speaker)
    {
        speakerText.text = speaker;
    }

    public void SetDialogue(string dialogue)
    {
        dialogueText.text = dialogue;
    }

    public void ChatOn()
    {
        chatObject.SetActive(true);
        nextButton.gameObject.SetActive(true);
        IsUIBlockingInput = true;
    }

    public void ChatOff()
    {
        chatObject.SetActive(false);
        nextButton.gameObject.SetActive(false);
        IsUIBlockingInput = false;
    }

    private void OnNextButtonClicked()
    {
        if (chatObject == null || !chatObject.activeInHierarchy)
            return;

        if (QuestManager.Instance == null)
        {
            Debug.LogError("[��ȭ UI] QuestManager�� �����ϴ�.");
            return;
        }

        QuestManager.Instance.NextDialogue();
    }
}
