public class QuestObjective
{
    public string Type;
    public string TargetID;
    public int Total;
    public int Current = 0;
}