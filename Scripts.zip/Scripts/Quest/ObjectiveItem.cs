using UnityEngine;
using UnityEngine.UI;

public class ObjectiveItem : MonoBehaviour
{
    public Text objectiveText;

    public void SetText(string text)
    {
        objectiveText.text = text;
    }
}
