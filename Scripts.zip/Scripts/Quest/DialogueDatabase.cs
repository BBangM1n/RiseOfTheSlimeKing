using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;

public class DialogueDatabase : MonoBehaviour
{
    public Dictionary<string, List<DialogueLine>> DialogueGroups = new();

    private bool isLoaded;

    public async UniTask LoadAll()
    {
        if (isLoaded)
            return;

        await LoadDialogues();
        isLoaded = true;

        Debug.Log("[��� ������ ���̽�] ��� �̸� ������ �ε� �Ϸ�");
    }

    private async UniTask LoadDialogues()
    {
        DialogueGroups.Clear();

        var data = await QuestCSVLoader.LoadCSV("Data/Dialogue");

        foreach (var row in data)
        {
            if (!row.TryGetValue("DialogueID", out var dialogueID) || string.IsNullOrEmpty(dialogueID))
                continue;

            DialogueLine line = new DialogueLine
            {
                DialogueID = dialogueID,
                Order = ParseInt(row, "Order", 0),
                Speaker = row.TryGetValue("Speaker", out var sp) ? sp : "",
                Text = row.TryGetValue("Text", out var txt) ? txt : "",
                NextDialogueID = row.TryGetValue("NextDialogueID", out var next) ? next : ""
            };

            if (!DialogueGroups.ContainsKey(dialogueID))
                DialogueGroups[dialogueID] = new List<DialogueLine>();

            DialogueGroups[dialogueID].Add(line);
        }

        foreach (var key in DialogueGroups.Keys)
            DialogueGroups[key].Sort((a, b) => a.Order.CompareTo(b.Order));

        int count = 0;
        foreach (var pair in DialogueGroups)
            count += pair.Value.Count;

        Debug.Log($"[��ȭ ������] �ε�� ��� �� : {count}");
    }

    public List<DialogueLine> GetDialogue(string dialogueID)
    {
        if (DialogueGroups.TryGetValue(dialogueID, out var list))
            return list;

        Debug.LogWarning($"[��ȭ ������] ��� ID�� ã�� �� �����ϴ�: {dialogueID}");
        return null;
    }

    private int ParseInt(Dictionary<string, string> row, string key, int def = 0)
    {
        if (!row.TryGetValue(key, out var s))
            return def;

        return int.TryParse(s, out var v) ? v : def;
    }
}
