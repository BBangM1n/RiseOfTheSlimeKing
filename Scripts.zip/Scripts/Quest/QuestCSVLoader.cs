using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using Cysharp.Threading.Tasks;

public static class QuestCSVLoader
{
    public static async UniTask<List<Dictionary<string, string>>> LoadCSV(string addressKey)
    {
        var list = new List<Dictionary<string, string>>();

        var handle = Addressables.LoadAssetAsync<TextAsset>(addressKey);
        TextAsset csvData = await handle.Task;

        if (handle.Status != AsyncOperationStatus.Succeeded || csvData == null)
        {
            Debug.LogError($"[CSV �δ�] CSV �ε� ����: {addressKey}");
            Addressables.Release(handle);
            return list;
        }

        try
        {
            list = ParseCSV(csvData.text);
        }
        catch (Exception e)
        {
            Debug.LogError($"[CSV �δ�] CSV �Ľ� ����: {addressKey}\n{e}");
        }

        Addressables.Release(handle);
        return list;
    }

    private static List<Dictionary<string, string>> ParseCSV(string csvText)
    {
        var list = new List<Dictionary<string, string>>();
        if (string.IsNullOrWhiteSpace(csvText))
            return list;

        string[] rows = csvText.Split('\n');
        if (rows.Length <= 1)
            return list;

        string[] headers = rows[0].Trim().Split(',');

        for (int i = 1; i < rows.Length; i++)
        {
            string row = rows[i];
            if (string.IsNullOrWhiteSpace(row))
                continue;

            string[] values = row.Trim().Split(',');
            var item = new Dictionary<string, string>(headers.Length);

            for (int j = 0; j < headers.Length; j++)
            {
                string key = headers[j];
                string val = (j < values.Length) ? values[j] : "";
                item[key] = val;
            }

            list.Add(item);
        }

        return list;
    }
}
