using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;

public class QuestDatabase : MonoBehaviour
{
    public Dictionary<string, Quest> Quests = new();

    private bool isLoaded;

    public async UniTask LoadAll()
    {
        if (isLoaded)
            return;

        await LoadQuests();
        await LoadObjectives();

        isLoaded = true;
        Debug.Log("[����Ʈ ������ ���̽�] ��� �̸� ������ �ε� �Ϸ�");
    }

    private async UniTask LoadQuests()
    {
        Quests.Clear();

        var data = await QuestCSVLoader.LoadCSV("Data/Quest");
        foreach (var row in data)
        {
            if (!row.ContainsKey("QuestID"))
                continue;

            Quest quest = new Quest
            {
                QuestID = row["QuestID"],
                Title = row.TryGetValue("Title", out var t) ? t : "",
                StartDialogueID = row.TryGetValue("StartDialogueID", out var sd) ? sd : "",
                ClearDialogueID = row.TryGetValue("ClearDialogueID", out var cd) ? cd : "",
                RewardID = row.TryGetValue("RewardID", out var r) ? r : "",
                NextQuestCode = row.TryGetValue("NextQuestCode", out var n) ? n : ""
            };

            Quests[quest.QuestID] = quest;
        }
    }

    private async UniTask LoadObjectives()
    {
        var data = await QuestCSVLoader.LoadCSV("Data/QuestObjectives");

        foreach (var row in data)
        {
            if (!row.TryGetValue("QuestID", out var questID))
                continue;

            if (!Quests.TryGetValue(questID, out var quest))
                continue;

            QuestObjective obj = new QuestObjective
            {
                Type = row.TryGetValue("Type", out var type) ? type : "",
                TargetID = row.TryGetValue("TargetID", out var target) ? target : "",
                Total = ParseInt(row, "Count", 0)
            };

            quest.Objectives.Add(obj);
        }
    }

    private int ParseInt(Dictionary<string, string> row, string key, int def)
    {
        if (!row.TryGetValue(key, out var s))
            return def;

        return int.TryParse(s, out var v) ? v : def;
    }
}
