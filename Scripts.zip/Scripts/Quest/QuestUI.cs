using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class QuestUI : MonoBehaviour
{
    public Text questTitleText;
    public Transform objectiveListParent;
    public GameObject objectiveItemPrefab;

    private readonly List<GameObject> spawnedObjectives = new();

    public void ShowQuest(Quest quest)
    {
        ClearObjectives();

        if (quest == null)
        {
            questTitleText.text = "[ �������� ����Ʈ�� �����ϴ� ]";
            return;
        }

        questTitleText.text = $"[ {quest.Title} ]";

        foreach (var obj in quest.Objectives)
        {
            GameObject go = Instantiate(objectiveItemPrefab, objectiveListParent);
            ObjectiveItem itemUI = go.GetComponent<ObjectiveItem>();

            string text = obj.Type switch
            {
                "Kill" => $"{LoadNameManager.Instance.GetKRName(obj.TargetID)} óġ ({obj.Current}/{obj.Total})",
                "Collect" => $"{LoadNameManager.Instance.GetKRName(obj.TargetID)} ���� ({obj.Current}/{obj.Total})",
                "Arrive" => $"{LoadNameManager.Instance.GetKRName(obj.TargetID)} ���� ({obj.Current}/{obj.Total})",
                "Talk" => $"{LoadNameManager.Instance.GetKRName(obj.TargetID)} ��ȭ",
                _ => ""
            };

            itemUI.SetText(text);
            spawnedObjectives.Add(go);
        }
    }

    private void ClearObjectives()
    {
        foreach (var obj in spawnedObjectives)
            Destroy(obj);

        spawnedObjectives.Clear();
    }
}
