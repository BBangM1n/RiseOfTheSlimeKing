using System.Collections.Generic;

public class Quest
{
    public string QuestID;
    public string Title;
    public string StartDialogueID;
    public string ClearDialogueID;
    public string RewardID;
    public string NextQuestCode;

    public List<QuestObjective> Objectives = new List<QuestObjective>();
}
