using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;

public class RewardDatabase : MonoBehaviour
{
    public Dictionary<string, QuestReward> Rewards = new();

    private bool isLoaded;

    public async UniTask LoadAll()
    {
        if (isLoaded)
            return;

        await LoadRewards();
        await LoadRewardItems();

        isLoaded = true;

        Debug.Log("[���� ������ ���̽�] ��� �̸� ������ �ε� �Ϸ�");
    }

    private async UniTask LoadRewards()
    {
        Rewards.Clear();

        var data = await QuestCSVLoader.LoadCSV("Data/Reward");
        foreach (var row in data)
        {
            if (!row.TryGetValue("RewardID", out var id))
                continue;

            QuestReward reward = new QuestReward
            {
                RewardID = id,
                Gold = ParseInt(row, "Gold", 0),
                Exp = ParseInt(row, "Exp", 0)
            };

            Rewards[id] = reward;
        }
    }

    private async UniTask LoadRewardItems()
    {
        var data = await QuestCSVLoader.LoadCSV("Data/RewardItem");
        foreach (var row in data)
        {
            if (!row.TryGetValue("RewardID", out var rewardID))
                continue;

            if (!Rewards.TryGetValue(rewardID, out var reward))
                continue;

            RewardItem item = new RewardItem
            {
                ItemID = row.TryGetValue("ItemID", out var id) ? id : "",
                Count = ParseInt(row, "Count", 1)
            };

            reward.Items.Add(item);
        }
    }

    private int ParseInt(Dictionary<string, string> row, string key, int def)
    {
        if (!row.TryGetValue(key, out var s))
            return def;

        return int.TryParse(s, out var v) ? v : def;
    }
}
