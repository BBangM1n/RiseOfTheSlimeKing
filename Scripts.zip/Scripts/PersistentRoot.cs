using UnityEngine;

public class PersistentRoot : MonoBehaviour
{
    public static PersistentRoot Instance;

    private static bool isCreated;

    private void Awake()
    {
        if (isCreated)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        isCreated = true;
        DontDestroyOnLoad(gameObject);
    }

    public static void HardReset()
    {
        if (Instance == null)
            return;

        Destroy(Instance.gameObject);
        Instance = null;
        isCreated = false;
    }
}
