﻿using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneLoader
{
    public static string TargetSceneName;
    public static string TargetSpawnPointID;

    public static void LoadScene(string sceneName, string spawnPointID = null)
    {
        TargetSceneName = sceneName;
        TargetSpawnPointID = spawnPointID;

        SceneManager.LoadScene("Loading");
    }
}
