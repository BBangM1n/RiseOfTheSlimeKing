﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public int gold;
    public string CurrentQuestCode;
    public bool isQuesting;

    public event Action<int> OnGoldChanged;
    public event Action<string> OnQuestChanged;
    public event Action OnQuestStateUpdated;

    public Dictionary<string, QuestState> QuestStates = new();
    public GameObject menuPanel;
    public GameObject helpPanel;

    public float totalPlaySeconds;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        if(!SaveManager.Instance.HasSaveData(SaveManager.Instance.CurrentSlotIndex))
        {
            helpPanel.SetActive(true);
        }
    }

    private void Update()
    {
        if (Time.timeScale > 0f)
            totalPlaySeconds += Time.deltaTime;
    }

    public void goldUpdate(int value)
    {
        gold += value;
        OnGoldChanged?.Invoke(gold);
    }

    public void QuestClear(string nextQuest)
    {
        CurrentQuestCode = nextQuest;
        OnQuestChanged?.Invoke(nextQuest);
    }

    public QuestState GetQuestState(string questCode)
    {
        return QuestStates.TryGetValue(questCode, out var state)
            ? state
            : QuestState.NotAccepted;
    }

    public void SetQuestState(string questCode, QuestState state)
    {
        QuestStates[questCode] = state;
        OnQuestStateUpdated?.Invoke();
    }

    public void OpenMenu()
    {
        menuPanel.SetActive(true);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
        Time.timeScale = 0f;
    }

    public void OpenHelp()
    {
        helpPanel.SetActive(true);
    }

    public void CloseHelp()
    {
        helpPanel.SetActive(false);
    }

    public void CloseMenu()
    {
        menuPanel.SetActive(false);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
        Time.timeScale = 1f;
    }

    public void OnClickSaveGame()
    {
        SaveManager.Instance.SaveGame();
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    public void OnClickMainMenu()
    {
        Time.timeScale = 1f;
        SaveManager.Instance.SaveGame();
        PersistentRoot.HardReset();
        SceneManager.LoadScene("Start");
    }

    public void OnClickExit()
    {
        Application.Quit();
    }

    public void RefreshUIAfterLoad()
    {
        OnGoldChanged?.Invoke(gold);
        OnQuestChanged?.Invoke(CurrentQuestCode);
        OnQuestStateUpdated?.Invoke();
    }
}
