﻿using System.Collections.Generic;
using UnityEngine;

public class NPC : MonoBehaviour
{
    [Header("NPC Info")]
    public string npcID;
    public string npcName;

    [TextArea] public string Dialogue;

    [Header("Quest Codes This NPC Can START")]
    public List<string> MyQuestID;

    [Header("Quest Marks")]
    [SerializeField] private GameObject questionMark;
    [SerializeField] private GameObject exclamationMark;

    private void Start()
    {
        RefreshQuestMarks();
    }

    private void OnEnable()
    {
        if (GameManager.Instance == null) return;

        GameManager.Instance.OnQuestChanged += OnQuestChanged;
        GameManager.Instance.OnQuestStateUpdated += RefreshQuestMarks;
    }

    private void OnDisable()
    {
        if (GameManager.Instance == null) return;

        GameManager.Instance.OnQuestChanged -= OnQuestChanged;
        GameManager.Instance.OnQuestStateUpdated -= RefreshQuestMarks;
    }

    private void OnQuestChanged(string questCode)
    {
        RefreshQuestMarks();
    }
    private void RefreshQuestMarks()
    {
        if (exclamationMark != null) exclamationMark.SetActive(false);
        if (questionMark != null) questionMark.SetActive(false);

        if (GameManager.Instance == null) return;

        string questCode = GameManager.Instance.CurrentQuestCode;
        if (string.IsNullOrEmpty(questCode)) return;

        QuestState state = GameManager.Instance.GetQuestState(questCode);

        bool canStartHere = (MyQuestID != null && MyQuestID.Contains(questCode));

        bool hasTalkObjective = (QuestManager.Instance != null && QuestManager.Instance.HasTalkObjective());
        bool isTalkTargetNpc = (QuestManager.Instance != null && QuestManager.Instance.IsTalkTarget(npcID));

        bool isReportNpc = hasTalkObjective ? isTalkTargetNpc : canStartHere;

        if (state == QuestState.NotAccepted && canStartHere)
        {
            if (exclamationMark != null) exclamationMark.SetActive(true);
        }

        if (state == QuestState.ReadyToClear && isReportNpc)
        {
            if (questionMark != null) questionMark.SetActive(true);
        }
    }

    public void Talk()
    {
        if (GameManager.Instance == null || ChatManager.Instance == null)
            return;

        if (QuestManager.Instance == null)
        {
            PlayNormalDialogue();
            return;
        }

        string questCode = GameManager.Instance.CurrentQuestCode;

        if (string.IsNullOrEmpty(questCode))
        {
            PlayNormalDialogue();
            return;
        }

        QuestState state = GameManager.Instance.GetQuestState(questCode);

        bool canStartHere = (MyQuestID != null && MyQuestID.Contains(questCode));

        bool hasTalkObjective = QuestManager.Instance.HasTalkObjective();
        bool isTalkTargetNpc = QuestManager.Instance.IsTalkTarget(npcID);

        bool isReportNpc = hasTalkObjective ? isTalkTargetNpc : canStartHere;

        if (state == QuestState.NotAccepted)
        {
            if (canStartHere)
            {
                QuestManager.Instance.StartQuest();
                RefreshQuestMarks();
            }
            else
            {
                PlayNormalDialogue();
            }
            return;
        }

        if (state == QuestState.InProgress)
        {
            if (hasTalkObjective && isTalkTargetNpc)
            {
                QuestManager.Instance.CheckObjective("Talk", npcID);

                if (GameManager.Instance.GetQuestState(questCode) == QuestState.ReadyToClear)
                {
                    if (isReportNpc)
                        QuestManager.Instance.CompleteQuest();
                    else
                        PlayNormalDialogue();
                }
                else
                {
                    PlayNormalDialogue();
                }

                RefreshQuestMarks();
                return;
            }

            PlayNormalDialogue();
            return;
        }

        if (state == QuestState.ReadyToClear)
        {
            if (isReportNpc)
            {
                QuestManager.Instance.CompleteQuest();
                RefreshQuestMarks();
            }
            else
            {
                PlayNormalDialogue();
            }
            return;
        }

        PlayNormalDialogue();
    }

    private void PlayNormalDialogue()
    {
        ChatManager.Instance.SetSpeaker(npcName);
        ChatManager.Instance.SetDialogue(Dialogue);
        ChatManager.Instance.ChatOn();
    }
}
