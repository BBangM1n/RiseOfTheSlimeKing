using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class ShopUI : MonoBehaviour
{
    [Header("Root")]
    [SerializeField] private GameObject root;

    [Header("Gold")]
    [SerializeField] private TextMeshProUGUI goldText;

    [Header("ScrollView")]
    [SerializeField] private Transform content;
    [SerializeField] private ShopItemSlot slotPrefab;

    [Header("Button")]
    [SerializeField] private Button closeButton;

    private void Awake()
    {
        closeButton.onClick.AddListener(Close);
        root.SetActive(false);
    }

    public void Open(List<Item> shopItems)
    {
        RefreshGold();

        foreach (Transform child in content)
            Destroy(child.gameObject);

        foreach (Item item in shopItems)
        {
            ShopItemSlot slot = Instantiate(slotPrefab, content);
            slot.Init(item);
            slot.buy += RefreshGold;
        }

        root.SetActive(true);
    }

    public void RefreshGold()
    {
        int gold = GameManager.Instance.gold;

        int tera = gold / 1_000_000;
        int mega = (gold / 1_000) % 1000;
        int bit = gold % 1000;

        goldText.text =
            $"{tera} <color=#FF0000>T</color> " +
            $"{mega} <color=#0DFF00>M</color> " +
            $"{bit} <color=#727272>B</color>";
    }

    public void Close()
    {
        foreach (Transform child in content)
        {
            ShopItemSlot slot = child.GetComponent<ShopItemSlot>();
            if (slot != null)
                slot.buy -= RefreshGold;
        }

        root.SetActive(false);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }
}
