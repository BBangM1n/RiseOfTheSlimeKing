﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class ShopItemSlot : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private Image iconImage;
    [SerializeField] private TextMeshProUGUI priceText;

    [Header("Stats")]
    [SerializeField] private TextMeshProUGUI adText;
    [SerializeField] private TextMeshProUGUI deText;
    [SerializeField] private TextMeshProUGUI hpText;
    [SerializeField] private TextMeshProUGUI mpText;

    [Header("Button")]
    [SerializeField] private Button buyButton;

    private Item item;
    private string iconKey;

    public event Action buy;

    public void Init(Item item)
    {
        this.item = item;

        nameText.text = item.Name;
        priceText.text = $"{item.Price} G";

        SetStatTexts(item);
        LoadIcon(item.Key);

        buyButton.onClick.RemoveAllListeners();
        buyButton.onClick.AddListener(OnClickBuy);
    }

    private void LoadIcon(string key)
    {
        iconKey = key;
        iconImage.sprite = null;
        iconImage.enabled = false;

        if (string.IsNullOrEmpty(key))
            return;

        ItemIconCache.Instance.Load(key, sprite =>
        {
            if (iconKey != key)
                return;

            iconImage.sprite = sprite;
            iconImage.enabled = sprite != null;
        });
    }

    private void SetStatTexts(Item item)
    {
        int ad = 0, de = 0, hp = 0, mp = 0;

        if (item is WeaponItem w)
        {
            ad = w.AttackPower;
            de = w.DefensePower;
            hp = w.HP;
            mp = w.MP;
        }

        adText.text = ad > 0 ? $"AD {ad}" : "AD -";
        deText.text = de > 0 ? $"DE {de}" : "DE -";
        hpText.text = hp > 0 ? $"HP {hp}" : "HP -";
        mpText.text = mp > 0 ? $"MP {mp}" : "MP -";
    }

    private void OnClickBuy()
    {
        if (GameManager.Instance.gold < item.Price)
        {
            LogPupupManager.Instance.AddLog(LogType.Gold, "골드가 부족합니다.");
            return;
        }

        if (!InventoryManager.Instance.CanAddItem(item))
        {
            LogPupupManager.Instance.AddLog(LogType.Item, "인벤토리가 가득 찼습니다.");
            return;
        }

        GameManager.Instance.goldUpdate(-item.Price);
        InventoryManager.Instance.AddItem(item);

        buy?.Invoke();

        ConsumableUI.Instance.Refresh();
        AudioManager.Instance?.PlaySfx(SfxType.Buy);

        SaveManager.Instance.SaveGame();
    }
}
