using UnityEngine;

public enum LogType
{
    Exp,
    Gold,
    Item,
    Consume,
    Material
}

public class LogPupupManager : MonoBehaviour
{
    public static LogPupupManager Instance;

    [SerializeField] private PoolManager poolManager;
    [SerializeField] private string logKey = "Chat";
    [SerializeField] private Transform logParent;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void AddLog(LogType type, string message)
    {
        GameObject obj = poolManager.GetObject(logKey, Vector3.zero, Quaternion.identity);
        obj.transform.SetParent(logParent, false);
        obj.transform.SetAsLastSibling();

        obj.GetComponent<LogText>().Init(type, message, () =>
        {
            poolManager.ReleaseObject(logKey, obj);
        });
    }

    public void AddExp(int amount) => AddLog(LogType.Exp, $"����ġ�� ȹ���Ͽ����ϴ�. (+{amount})");
    public void AddGold(int amount) => AddLog(LogType.Gold, $"��带 ȹ���Ͽ����ϴ�. (+{amount})");
    public void AddItem(string name) => AddLog(LogType.Item, $"��� ������ ȹ��: {name}");
    public void AddConsume(string name) => AddLog(LogType.Consume, $"�Һ� ������ ȹ��: {name}");
    public void AddMaterial(string name) => AddLog(LogType.Material, $"��� ������ ȹ��: {name}");
}
