using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("HP")]
    [SerializeField] private Slider hpSlider;
    [SerializeField] private TextMeshProUGUI hpText;
    private int currentHp;
    private int maxHp;

    [Header("MP")]
    [SerializeField] private Slider mpSlider;
    [SerializeField] private TextMeshProUGUI mpText;
    private int currentMp;
    private int maxMp;

    [Header("EXP")]
    [SerializeField] private Slider expSlider;
    [SerializeField] private TextMeshProUGUI expText;
    private int currentExp;
    private int maxExp;

    [Header("Etc")]
    [SerializeField] private TextMeshProUGUI goldText;
    [SerializeField] private TextMeshProUGUI levelText;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void OnEnable()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.OnGoldChanged += SetGoldText;
    }

    private void OnDisable()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.OnGoldChanged -= SetGoldText;
    }

    public void InitializeHP(int current, int max)
    {
        maxHp = max;
        currentHp = current;

        hpSlider.maxValue = max;
        hpSlider.value = current;

        hpText.text = $"{maxHp} / {currentHp}";
    }

    public void InitializeMP(int current, int max)
    {
        maxMp = max;
        currentMp = current;

        mpSlider.maxValue = max;
        mpSlider.value = current;

        mpText.text = $"{maxMp} / {currentMp}";
    }

    public void InitializeEXP(int current, int max)
    {
        maxExp = max;
        currentExp = current;

        expSlider.maxValue = max;
        expSlider.value = current;

        expText.text = $"{currentExp} ( {(float)currentExp / maxExp * 100f:F1} % )";
    }

    public void SetHP(int current)
    {
        currentHp = current;

        hpSlider.DOKill();
        hpSlider.DOValue(currentHp, 0.3f).SetEase(Ease.OutQuad);

        hpText.text = $"{maxHp} / {currentHp}";
    }

    public void SetMP(int current)
    {
        currentMp = current;

        mpSlider.DOKill();
        mpSlider.DOValue(currentMp, 0.3f).SetEase(Ease.OutQuad);

        mpText.text = $"{maxMp}  /  {currentMp}";
    }

    public void SetEXP(int current)
    {
        currentExp = current;

        expSlider.DOKill();
        expSlider.DOValue(currentExp, 0.3f).SetEase(Ease.OutQuad);

        expText.text = $"{currentExp} ( {(float)currentExp / maxExp * 100f:F1} % )";
    }

    public void SetGoldText(int gold)
    {
        int tera = gold / 1_000_000;
        int mega = (gold / 1_000) % 1_000;
        int bit = gold % 1_000;

        goldText.text =
            $"{tera} <color=#FF0000>T</color> " +
            $"{mega} <color=#0DFF00>M</color> " +
            $"{bit} <color=#727272>B</color>";
    }

    public void SetLevelText(int level)
    {
        levelText.text = $"Lv. {level}";
    }
}
