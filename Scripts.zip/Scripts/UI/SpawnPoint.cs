using UnityEngine;

public class SpawnPoint : MonoBehaviour
{
    public string spawnPointID;
}
