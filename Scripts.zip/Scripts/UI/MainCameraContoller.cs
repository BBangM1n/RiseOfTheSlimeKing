using UnityEngine;
using UnityEngine.SceneManagement;

public class MainCameraContoller : MonoBehaviour
{
    private Transform player;

    [SerializeField] private float smoothing = 0.2f;
    [SerializeField] private Vector2 minCameraBoundary;
    [SerializeField] private Vector2 maxCameraBoundary;

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        GameObject p = GameObject.FindGameObjectWithTag("Player");
        if (p != null)
            player = p.transform;
    }

    private void LateUpdate()
    {
        if (player == null) return;

        Vector3 target = new Vector3(
            Mathf.Clamp(player.position.x, minCameraBoundary.x, maxCameraBoundary.x),
            Mathf.Clamp(player.position.y, minCameraBoundary.y, maxCameraBoundary.y),
            transform.position.z
        );

        transform.position = Vector3.Lerp(transform.position, target, smoothing);
    }
}
