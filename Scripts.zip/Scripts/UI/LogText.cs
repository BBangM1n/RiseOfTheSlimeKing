using TMPro;
using UnityEngine;
using Cysharp.Threading.Tasks;
using System;

public class LogText : MonoBehaviour
{
    public TextMeshProUGUI text;
    public float displayTime = 2f;
    public float fadeTime = 1f;

    private Action onComplete;
    private bool released;

    public void Init(LogType type, string message, Action onComplete)
    {
        this.onComplete = onComplete;
        released = false;

        text.color = type switch
        {
            LogType.Exp => Color.green,
            LogType.Gold => Color.yellow,
            LogType.Item => Color.cyan,
            LogType.Consume => new Color(1f, 0.5f, 0.5f),
            _ => Color.white
        };

        text.text = message;
        FadeOut().Forget();
    }

    private async UniTaskVoid FadeOut()
    {
        await UniTask.Delay((int)(displayTime * 1000));

        float t = 0f;
        Color origin = text.color;

        while (t < fadeTime)
        {
            if (released) return;
            t += Time.deltaTime;
            text.color = new Color(origin.r, origin.g, origin.b, Mathf.Lerp(1f, 0f, t / fadeTime));
            await UniTask.Yield();
        }

        Release();
    }

    private void Release()
    {
        if (released) return;
        released = true;
        onComplete?.Invoke();
    }
}
