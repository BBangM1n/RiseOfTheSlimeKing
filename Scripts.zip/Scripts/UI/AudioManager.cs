﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum SfxType
{
    Buy,
    MonsterHit,
    PlayerAttack,
    ButtonClick,
    PotionUse,
    Equip,
    Get,
    Dash,
    LevelUp,
    PlayerDie,
    PlayerHit,
    OpenShop,
    BossAttack1,
    BossAttack2,
    BossAttack3,
}

[Serializable]
public class SfxEntry
{
    public SfxType type;
    public AudioClip clip;
}

public enum BgmType
{
    None,
    Title,
    Field,
    Boss
}

[Serializable]
public class BgmEntry
{
    public BgmType type;
    public AudioClip clip;
}

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;

    [Header("BGM")]
    [SerializeField] private AudioSource bgmSource;
    [SerializeField] private BgmEntry[] bgmEntries;

    [Header("SFX")]
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private SfxEntry[] sfxEntries;

    private readonly Dictionary<BgmType, AudioClip> bgmMap = new();
    private readonly Dictionary<SfxType, AudioClip> sfxMap = new();

    private BgmType currentBgmType = BgmType.None;

    public float BgmVolume
    {
        get => bgmSource != null ? bgmSource.volume : 0f;
        set
        {
            if (bgmSource == null) return;
            bgmSource.volume = Mathf.Clamp01(value);
        }
    }

    public float SfxVolume
    {
        get => sfxSource != null ? sfxSource.volume : 0f;
        set
        {
            if (sfxSource == null) return;
            sfxSource.volume = Mathf.Clamp01(value);
        }
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        foreach (var entry in sfxEntries)
        {
            if (entry.clip != null)
                sfxMap[entry.type] = entry.clip;
        }

        foreach (var entry in bgmEntries)
        {
            if (entry.clip != null)
                bgmMap[entry.type] = entry.clip;
        }

        if (bgmSource != null) bgmSource.volume = 0.3f;
        if (sfxSource != null) sfxSource.volume = 0.3f;

        SceneManager.sceneLoaded += OnSceneLoaded;
        ChangeBgmBySceneName(SceneManager.GetActiveScene().name);
    }

    private void OnDestroy()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        ChangeBgmBySceneName(scene.name);
    }

    private BgmType GetBgmTypeForScene(string sceneName)
    {
        return sceneName switch
        {
            "Start" => BgmType.Title,
            "Load" or "DownLoad" or "Loading" => currentBgmType,
            "Main" or "Field1" or "Field2" or "Field3" or "Field4" => BgmType.Field,
            "Field5" => BgmType.Boss,
            _ => BgmType.None
        };
    }

    private void ChangeBgmBySceneName(string sceneName)
    {
        BgmType targetType = GetBgmTypeForScene(sceneName);
        if (targetType == currentBgmType)
            return;

        currentBgmType = targetType;

        if (targetType == BgmType.None)
        {
            StopBgm();
            return;
        }

        if (!bgmMap.TryGetValue(targetType, out AudioClip clip))
            return;

        PlayBgm(clip);
    }

    public void PlayBgm(AudioClip clip, bool loop = true)
    {
        if (bgmSource == null || clip == null) return;

        bgmSource.clip = clip;
        bgmSource.loop = loop;
        bgmSource.Play();
    }

    public void StopBgm()
    {
        if (bgmSource == null) return;
        bgmSource.Stop();
        currentBgmType = BgmType.None;
    }

    public void PlaySfx(SfxType type, float volume = 1f)
    {
        if (sfxSource == null) return;
        if (!sfxMap.TryGetValue(type, out AudioClip clip)) return;

        sfxSource.PlayOneShot(clip, volume);
    }
    public void SetBgmVolume(float value)
    {
        BgmVolume = value;
    }

    public void SetSfxVolume(float value)
    {
        SfxVolume = value;
    }
}
