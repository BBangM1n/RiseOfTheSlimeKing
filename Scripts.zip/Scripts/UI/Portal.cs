using UnityEngine;

public class Portal : MonoBehaviour
{
    [SerializeField] private Transform destination;
    [SerializeField] private KeyCode interactKey = KeyCode.UpArrow;

    private bool isPlayerInside;
    private Transform player;

    private void Update()
    {
        if (!isPlayerInside)
            return;

        if (Input.GetKeyDown(interactKey))
            Teleport();
    }

    private void Teleport()
    {
        if (player == null || destination == null)
            return;

        player.position = destination.position;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player"))
            return;

        isPlayerInside = true;
        player = other.transform;
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("Player"))
            return;

        isPlayerInside = false;
        player = null;
    }
}
