﻿using UnityEngine;

public class CloudLooper : MonoBehaviour
{
    [SerializeField] private Camera mainCamera;
    [SerializeField] private SpriteRenderer[] clouds;
    [SerializeField] private float speed = 1f;
    [SerializeField] private float overlap = 0.1f;

    private float[] cloudWidths;

    private void Start()
    {
        if (mainCamera == null)
            mainCamera = Camera.main;

        if (clouds == null || clouds.Length < 3)
        {
            Debug.LogError("구름은 최소 3개 이상 필요합니다.");
            return;
        }

        cloudWidths = new float[clouds.Length];
        FitAndMeasureClouds();
        PositionClouds();
    }

    private void Update()
    {
        for (int i = 0; i < clouds.Length; i++)
            clouds[i].transform.position += Vector3.left * speed * Time.deltaTime;

        float leftEdge = -mainCamera.orthographicSize * mainCamera.aspect;

        for (int i = 0; i < clouds.Length; i++)
        {
            if (clouds[i].transform.position.x + cloudWidths[i] * 0.5f < leftEdge)
            {
                float rightMost = float.MinValue;
                for (int j = 0; j < clouds.Length; j++)
                {
                    float edge = clouds[j].transform.position.x + cloudWidths[j] * 0.5f;
                    if (edge > rightMost) rightMost = edge;
                }

                clouds[i].transform.position = new Vector3(
                    rightMost + cloudWidths[i] * 0.5f - overlap,
                    clouds[i].transform.position.y,
                    clouds[i].transform.position.z
                );
            }
        }
    }

    private void FitAndMeasureClouds()
    {
        float screenHeight = mainCamera.orthographicSize * 2f;
        float screenWidth = screenHeight * mainCamera.aspect;

        SpriteRenderer baseCloud = clouds[0];
        float scale = Mathf.Max(
            screenWidth / baseCloud.sprite.bounds.size.x,
            screenHeight / baseCloud.sprite.bounds.size.y
        );

        for (int i = 0; i < clouds.Length; i++)
        {
            clouds[i].transform.localScale = Vector3.one * scale;
            cloudWidths[i] = clouds[i].sprite.bounds.size.x * scale;
        }
    }

    private void PositionClouds()
    {
        for (int i = 1; i < clouds.Length; i++)
        {
            float prevEdge = clouds[i - 1].transform.position.x + cloudWidths[i - 1] * 0.5f;
            clouds[i].transform.position = new Vector3(
                prevEdge + cloudWidths[i] * 0.5f - overlap,
                clouds[i].transform.position.y,
                clouds[i].transform.position.z
            );
        }
    }
}
