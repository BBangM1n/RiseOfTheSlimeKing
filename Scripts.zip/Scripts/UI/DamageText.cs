﻿using TMPro;
using UnityEngine;
using DG.Tweening;

public class DamageText : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI text;

    private string poolKey;
    private Tween tween;

    public void Init(string key)
    {
        poolKey = key;
    }

    public void Play(int damage, float scale = 1f)
    {
        if (text == null)
            return;

        text.text = damage.ToString();
        text.alpha = 1f;

        transform.localScale = Vector3.one * scale;

        tween?.Kill();
        tween = DOTween.Sequence()
            .Append(transform.DOLocalMoveY(transform.localPosition.y + 0.6f, 1f))
            .Join(text.DOFade(0f, 1f))
            .OnComplete(Release);
    }
    public void Play(int damage, Color color, float scale = 1f)
    {
        if (text == null)
            return;

        Play(damage, scale);
    }

    private void Release()
    {
        ResetState();

        if (PoolManager.Instance != null && !string.IsNullOrEmpty(poolKey))
            PoolManager.Instance.ReleaseObject(poolKey, gameObject);
        else
            gameObject.SetActive(false);
    }

    private void ResetState()
    {
        tween?.Kill();
        tween = null;

        if (text != null)
        {
            text.text = string.Empty;
            text.alpha = 0f;
        }

        transform.localPosition = Vector3.zero;
        transform.localScale = Vector3.one;
    }

    private void OnDisable()
    {
        ResetState();
    }
}
