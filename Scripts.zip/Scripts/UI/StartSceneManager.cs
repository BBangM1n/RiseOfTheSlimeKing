using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartSceneManager : MonoBehaviour
{
    [SerializeField] private Button startButton;
    [SerializeField] private TextMeshProUGUI tmpText;

    [SerializeField] private float speed = 2f;
    [SerializeField] private float minAlpha = 0.2f;
    [SerializeField] private float maxAlpha = 1f;

    private void Start()
    {
        if (startButton != null)
            startButton.onClick.AddListener(OnClickStartGame);
    }

    private void Update()
    {
        if (tmpText == null)
            return;

        Color color = tmpText.color;
        float t = Mathf.PingPong(Time.unscaledTime * speed, 1f);
        color.a = Mathf.Lerp(minAlpha, maxAlpha, t);
        tmpText.color = color;
    }

    private void OnClickStartGame()
    {
        SceneManager.LoadScene("Load");
    }
}
