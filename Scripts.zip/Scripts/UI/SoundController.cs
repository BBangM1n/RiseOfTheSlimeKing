﻿using UnityEngine;
using UnityEngine.UI;

public class SoundController : MonoBehaviour
{
    private const string BGM_KEY = "BgmVolume";
    private const string SFX_KEY = "SfxVolume";

    [Header("BGM")]
    [SerializeField] private Slider bgmSlider;
    [SerializeField] private Button bgmPlusButton;
    [SerializeField] private Button bgmMinusButton;
    [SerializeField] private Button bgmToggleButton;
    [SerializeField] private GameObject bgmOnObject;
    [SerializeField] private GameObject bgmOffObject;

    [Header("SFX")]
    [SerializeField] private Slider sfxSlider;
    [SerializeField] private Button sfxPlusButton;
    [SerializeField] private Button sfxMinusButton;
    [SerializeField] private Button sfxToggleButton;
    [SerializeField] private GameObject sfxOnObject;
    [SerializeField] private GameObject sfxOffObject;

    private float savedBgmVolume = 1f;
    private float savedSfxVolume = 1f;
    private bool isBgmOn = true;
    private bool isSfxOn = true;

    private void Start()
    {
        if (PlayerPrefs.HasKey(BGM_KEY))
            savedBgmVolume = PlayerPrefs.GetFloat(BGM_KEY);

        if (PlayerPrefs.HasKey(SFX_KEY))
            savedSfxVolume = PlayerPrefs.GetFloat(SFX_KEY);

        if (AudioManager.Instance != null)
        {
            AudioManager.Instance.SetBgmVolume(savedBgmVolume);
            AudioManager.Instance.SetSfxVolume(savedSfxVolume);
        }
        else
        {
            Debug.LogError("[사운드 컨트롤러] AudioManager가 없습니다.");
        }

        if (bgmSlider != null) bgmSlider.value = savedBgmVolume;
        if (sfxSlider != null) sfxSlider.value = savedSfxVolume;

        isBgmOn = savedBgmVolume > 0.001f;
        isSfxOn = savedSfxVolume > 0.001f;

        UpdateIcons();

        if (bgmSlider != null)
            bgmSlider.onValueChanged.AddListener(OnBgmChanged);
        if (sfxSlider != null)
            sfxSlider.onValueChanged.AddListener(OnSfxChanged);

        bgmPlusButton?.onClick.AddListener(() => AddBgmVolume(0.1f));
        bgmMinusButton?.onClick.AddListener(() => AddBgmVolume(-0.1f));
        sfxPlusButton?.onClick.AddListener(() => AddSfxVolume(0.1f));
        sfxMinusButton?.onClick.AddListener(() => AddSfxVolume(-0.1f));

        bgmToggleButton?.onClick.AddListener(ToggleBgm);
        sfxToggleButton?.onClick.AddListener(ToggleSfx);
    }

    private void OnBgmChanged(float value)
    {
        AudioManager.Instance?.SetBgmVolume(value);
        PlayerPrefs.SetFloat(BGM_KEY, value);

        isBgmOn = value > 0.001f;
        UpdateIcons();
    }

    private void OnSfxChanged(float value)
    {
        AudioManager.Instance?.SetSfxVolume(value);
        PlayerPrefs.SetFloat(SFX_KEY, value);

        isSfxOn = value > 0.001f;
        UpdateIcons();
    }

    private void AddBgmVolume(float amount)
    {
        if (bgmSlider == null) return;
        bgmSlider.value = Mathf.Clamp01(bgmSlider.value + amount);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    private void AddSfxVolume(float amount)
    {
        if (sfxSlider == null) return;
        sfxSlider.value = Mathf.Clamp01(sfxSlider.value + amount);
        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    private void ToggleBgm()
    {
        if (bgmSlider == null) return;

        if (isBgmOn)
        {
            savedBgmVolume = bgmSlider.value;
            bgmSlider.value = 0f;
        }
        else
        {
            bgmSlider.value = savedBgmVolume <= 0f ? 0.5f : savedBgmVolume;
        }

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    private void ToggleSfx()
    {
        if (sfxSlider == null) return;

        if (isSfxOn)
        {
            savedSfxVolume = sfxSlider.value;
            sfxSlider.value = 0f;
        }
        else
        {
            sfxSlider.value = savedSfxVolume <= 0f ? 0.5f : savedSfxVolume;
        }

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    private void UpdateIcons()
    {
        if (bgmOnObject != null) bgmOnObject.SetActive(isBgmOn);
        if (bgmOffObject != null) bgmOffObject.SetActive(!isBgmOn);
        if (sfxOnObject != null) sfxOnObject.SetActive(isSfxOn);
        if (sfxOffObject != null) sfxOffObject.SetActive(!isSfxOn);
    }

    public void ApplyFromSave(float bgm, float sfx)
    {
        savedBgmVolume = bgm;
        savedSfxVolume = sfx;

        if (bgmSlider != null) bgmSlider.value = bgm;
        if (sfxSlider != null) sfxSlider.value = sfx;

        PlayerPrefs.SetFloat(BGM_KEY, bgm);
        PlayerPrefs.SetFloat(SFX_KEY, sfx);

        isBgmOn = bgm > 0.001f;
        isSfxOn = sfx > 0.001f;
        UpdateIcons();
    }
}
