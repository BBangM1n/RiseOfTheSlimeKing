﻿using UnityEngine;

public class Warp : MonoBehaviour
{
    [SerializeField] private string warpSceneName;
    [SerializeField] private string targetSpawnPointID;

    private bool isPlayerInside;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Player"))
            return;

        isPlayerInside = true;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (!collision.CompareTag("Player"))
            return;

        isPlayerInside = false;
    }

    private void Update()
    {
        if (!isPlayerInside)
            return;

        if (Input.GetKeyDown(KeyCode.UpArrow))
            WarpToScene();
    }

    private void WarpToScene()
    {
        if (string.IsNullOrEmpty(warpSceneName))
        {
            Debug.LogWarning("[워프] 이동할 씬 이름이 설정되지 않았습니다.");
            return;
        }

        if (SaveManager.Instance != null)
            SaveManager.Instance.SaveGame();

        SceneLoader.LoadScene(warpSceneName, targetSpawnPointID);
    }
}
