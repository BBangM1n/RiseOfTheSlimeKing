﻿using System;
using System.Collections.Generic;

[Serializable]
public class SaveData
{
    public int level;
    public int currentEXP;
    public int skillPoint;
    public int maxEXP;

    public float baseMaxHP;
    public float baseMaxMP;
    public float baseDamage;
    public float baseDefense;

    public int gold;
    public string currentQuestCode;

    public List<QuestStateSave> questStates = new();
    public List<QuestProgressSave> questProgresses = new();

    public List<InventoryItemSave> inventoryItems = new();
    public List<EquippedItemSave> equippedItems = new();
    public List<EquippedSkillSave> equippedSkills = new();

    public string saveTime;
    public int playTimeSeconds;

    public float bgmVolume = 1f;
    public float sfxVolume = 1f;
}

[Serializable]
public class QuestStateSave
{
    public string questCode;
    public QuestState state;
}

[Serializable]
public class QuestProgressSave
{
    public string questCode;
    public List<int> objectiveCurrents = new();
}

[Serializable]
public class InventoryItemSave
{
    public InventoryItemCategory category;
    public string itemCode;
    public int count;
}

[Serializable]
public class EquippedItemSave
{
    public EquipSlot equipSlot;
    public string itemCode;
}

[Serializable]
public class EquippedSkillSave
{
    public string key;
    public int skillCode;
}
