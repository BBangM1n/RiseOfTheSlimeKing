﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.UI;

public class DownLoad : MonoBehaviour
{
    private const string NextSceneName = "Main";

    [Header("Addressables")]
    [SerializeField] private AssetLabelReference[] labels;

    [Header("UI")]
    [SerializeField] private Slider downSlider;
    [SerializeField] private Text headerText;
    [SerializeField] private Text sizeInfoText;
    [SerializeField] private Text downValText;

    [Header("Buttons")]
    [SerializeField] private GameObject downloadButtonObject;

    private long totalDownloadSize;
    private readonly Dictionary<string, long> patchMap = new();
    private readonly List<string> labelsToDownload = new();

    private void Start()
    {
        SetCheckingUI();
        StartCoroutine(InitializeAndCheckRoutine());
    }

    private IEnumerator InitializeAndCheckRoutine()
    {
        var initHandle = Addressables.InitializeAsync();
        yield return initHandle;

        yield return CheckUpdateFilesRoutine();
    }

    private IEnumerator CheckUpdateFilesRoutine()
    {
        totalDownloadSize = 0;
        labelsToDownload.Clear();
        patchMap.Clear();

        if (labels == null || labels.Length == 0)
        {
            Debug.LogWarning("[DownLoad] No labels set in inspector.");
            SetUpToDateUI();
            yield return new WaitForSeconds(1f);
            SceneLoader.LoadScene(NextSceneName);
            yield break;
        }

        foreach (var labelRef in labels)
        {
            if (labelRef == null || string.IsNullOrEmpty(labelRef.labelString))
                continue;

            string label = labelRef.labelString;

            var sizeHandle = Addressables.GetDownloadSizeAsync(label);
            yield return sizeHandle;

            long size = sizeHandle.Result;
            Addressables.Release(sizeHandle);

            if (size > 0)
            {
                totalDownloadSize += size;
                labelsToDownload.Add(label);
                patchMap[label] = 0;
            }
        }

        if (totalDownloadSize > 0 && labelsToDownload.Count > 0)
        {
            SetNeedUpdateUI(totalDownloadSize);
            yield break;
        }

        SetUpToDateUI();
        yield return new WaitForSeconds(2f);
        SceneLoader.LoadScene(NextSceneName);
    }

    public void OnClickDownloadButton()
    {
        if (totalDownloadSize <= 0 || labelsToDownload.Count == 0)
        {
            SceneLoader.LoadScene(NextSceneName);
            return;
        }

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
        StartCoroutine(DownloadRoutine());
    }

    private IEnumerator DownloadRoutine()
    {
        SetDownloadStartUI();

        foreach (var label in labelsToDownload)
        {
            StartCoroutine(DownloadLabelRoutine(label));
        }

        yield return TrackProgressRoutine();

        SetDownloadCompleteUI();
        SceneLoader.LoadScene(NextSceneName);
    }

    private IEnumerator DownloadLabelRoutine(string label)
    {
        var handle = Addressables.DownloadDependenciesAsync(label, false);

        while (!handle.IsDone)
        {
            var status = handle.GetDownloadStatus();
            patchMap[label] = (long)status.DownloadedBytes;
            yield return null;
        }

        var finalStatus = handle.GetDownloadStatus();
        patchMap[label] = (long)finalStatus.TotalBytes;

        Addressables.Release(handle);
    }

    private IEnumerator TrackProgressRoutine()
    {
        while (true)
        {
            long downloaded = patchMap.Values.Sum();

            float progress = totalDownloadSize > 0
                ? (float)downloaded / totalDownloadSize
                : 1f;

            progress = Mathf.Clamp01(progress);
            UpdateProgressUI(progress);

            bool allDone = patchMap.Count > 0 && patchMap.Values.All(v => v > 0);
            bool reachedTotal = downloaded >= totalDownloadSize;

            if (reachedTotal && allDone)
                yield break;

            yield return null;
        }
    }

    private void SetCheckingUI()
    {
        if (downloadButtonObject != null)
            downloadButtonObject.SetActive(false);

        if (headerText != null)
            headerText.text = "업데이트 확인 중입니다.";

        if (sizeInfoText != null)
            sizeInfoText.text = "";

        if (downValText != null)
            downValText.text = "";

        if (downSlider != null)
            downSlider.value = 0f;
    }

    private void SetNeedUpdateUI(long totalSize)
    {
        if (headerText != null)
            headerText.text = "업데이트된 내용이 있습니다.";

        if (sizeInfoText != null)
            sizeInfoText.text = "파일 사이즈 : " + GetFileSize(totalSize);

        if (downloadButtonObject != null)
            downloadButtonObject.SetActive(true);

        UpdateProgressUI(0f);
    }

    private void SetUpToDateUI()
    {
        if (headerText != null)
            headerText.text = "최신 버전입니다.";

        if (sizeInfoText != null)
            sizeInfoText.text = "";

        UpdateProgressUI(1f);

        if (downloadButtonObject != null)
            downloadButtonObject.SetActive(false);
    }

    private void SetDownloadStartUI()
    {
        if (downloadButtonObject != null)
            downloadButtonObject.SetActive(false);

        if (headerText != null)
            headerText.text = "다운로드 중입니다.";
    }

    private void SetDownloadCompleteUI()
    {
        if (headerText != null)
            headerText.text = "다운로드 완료!";

        UpdateProgressUI(1f);
    }

    private void UpdateProgressUI(float progress01)
    {
        if (downSlider != null)
            downSlider.value = progress01;

        if (downValText != null)
            downValText.text = $"{(int)(progress01 * 100f)} %";
    }

    private static string GetFileSize(long bytes)
    {
        const double KB = 1024.0;
        const double MB = KB * 1024.0;
        const double GB = MB * 1024.0;

        if (bytes >= GB) return $"{bytes / GB:##.##} GB";
        if (bytes >= MB) return $"{bytes / MB:##.##} MB";
        if (bytes >= KB) return $"{bytes / KB:##.##} KB";
        return $"{bytes} Bytes";
    }
}
