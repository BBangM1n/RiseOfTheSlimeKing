﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public sealed class SaveManager : MonoBehaviour
{
    public static SaveManager Instance { get; private set; }

    public int CurrentSlotIndex { get; private set; }
    public bool ShouldLoadOnMain { get; private set; }

    private const int MinSlotIndex = 0;
    private const int MaxSlotIndex = 2;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void SelectSlot(int slotIndex, bool loadOnMain)
    {
        CurrentSlotIndex = Mathf.Clamp(slotIndex, MinSlotIndex, MaxSlotIndex);
        ShouldLoadOnMain = loadOnMain;
    }

    public string GetSavePath(int slotIndex)
    {
        return Path.Combine(Application.persistentDataPath, $"save_{slotIndex}.json");
    }

    public bool HasSaveData(int slotIndex)
    {
        return File.Exists(GetSavePath(slotIndex));
    }

    public void SaveGame()
    {
        SaveGame(CurrentSlotIndex);
    }

    public void SaveGame(int slotIndex)
    {
        var data = new SaveData();

        FillPlayerData(data);
        FillGameManagerData(data);
        FillOptionalManagersData(data);
        FillInventoryData(data);
        FillAudioData(data);
        FillTimeData(data);

        WriteToDisk(slotIndex, data);
    }

    public void LoadGame()
    {
        LoadGame(CurrentSlotIndex);
    }

    public void LoadGame(int slotIndex)
    {
        string path = GetSavePath(slotIndex);
        if (!File.Exists(path))
        {
            Debug.LogWarning($"[SaveManager] 세이브 파일이 없습니다 : {path}");
            return;
        }

        SaveData data = ReadFromDisk(path);

        ApplyPlayerData(data);
        ApplyGameManagerData(data);
        ApplyOptionalManagersData(data);
        ApplyInventoryData(data);
        ApplyTimeData(data);
        ApplyAudioData(data);

        ShouldLoadOnMain = false;

        Debug.Log($"[SaveManager] Load complete: {path}");
        GameManager.Instance.RefreshUIAfterLoad();
    }

    public void DeleteSave(int slotIndex)
    {
        string path = GetSavePath(slotIndex);
        if (!File.Exists(path))
            return;

        File.Delete(path);
        Debug.Log($"[SaveManager] Save deleted: {path}");
    }

    // Save

    private static void FillPlayerData(SaveData data)
    {
        var player = FindObjectOfType<PlayerModel>();
        player?.FillSaveData(data);
    }

    private static void FillGameManagerData(SaveData data)
    {
        data.gold = GameManager.Instance.gold;
        data.currentQuestCode = GameManager.Instance.CurrentQuestCode;

        data.questStates = new List<QuestStateSave>();
        foreach (var kv in GameManager.Instance.QuestStates)
        {
            data.questStates.Add(new QuestStateSave
            {
                questCode = kv.Key,
                state = kv.Value
            });
        }
    }

    private static void FillOptionalManagersData(SaveData data)
    {
        QuestManager.Instance?.FillSaveData(data);
        SkillManager.Instance?.FillSaveData(data);
    }

    private static void FillInventoryData(SaveData data)
    {
        InventoryManager.Instance.FillSaveData(data);
    }

    private static void FillAudioData(SaveData data)
    {
        if (AudioManager.Instance == null)
            return;

        data.bgmVolume = AudioManager.Instance.BgmVolume;
        data.sfxVolume = AudioManager.Instance.SfxVolume;
    }

    private static void FillTimeData(SaveData data)
    {
        data.saveTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
        data.playTimeSeconds = (int)GameManager.Instance.totalPlaySeconds;
    }

    private static void WriteToDisk(int slotIndex, SaveData data)
    {
        string path = Instance.GetSavePath(slotIndex);
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(path, json);

        Debug.Log($"[SaveManager] Save complete: {path}");
    }

    // Load

    private static SaveData ReadFromDisk(string path)
    {
        string json = File.ReadAllText(path);
        return JsonUtility.FromJson<SaveData>(json);
    }

    private static void ApplyPlayerData(SaveData data)
    {
        var player = FindObjectOfType<PlayerModel>();
        player?.ApplySaveData(data);
    }

    private static void ApplyGameManagerData(SaveData data)
    {
        GameManager.Instance.gold = data.gold;
        GameManager.Instance.CurrentQuestCode = data.currentQuestCode;

        GameManager.Instance.QuestStates.Clear();
        foreach (var qs in data.questStates)
        {
            GameManager.Instance.QuestStates[qs.questCode] = qs.state;
        }
    }

    private static void ApplyOptionalManagersData(SaveData data)
    {
        QuestManager.Instance?.ApplySaveData(data);
        SkillManager.Instance?.ApplySaveData(data);
    }

    private static void ApplyInventoryData(SaveData data)
    {
        InventoryManager.Instance.ApplySaveData(data);
    }

    private static void ApplyTimeData(SaveData data)
    {
        GameManager.Instance.totalPlaySeconds = data.playTimeSeconds;
    }

    private static void ApplyAudioData(SaveData data)
    {
        float bgm = data.bgmVolume;
        float sfx = data.sfxVolume;

        var soundController = FindObjectOfType<SoundController>();
        if (soundController != null)
        {
            soundController.ApplyFromSave(bgm, sfx);
            return;
        }

        if (AudioManager.Instance != null)
        {
            AudioManager.Instance.BgmVolume = bgm;
            AudioManager.Instance.SfxVolume = sfx;
        }

        PlayerPrefs.SetFloat("BgmVolume", bgm);
        PlayerPrefs.SetFloat("SfxVolume", sfx);
    }
}
