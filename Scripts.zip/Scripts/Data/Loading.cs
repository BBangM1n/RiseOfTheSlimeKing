﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Loading : MonoBehaviour
{
    [SerializeField] private Slider loadingBar;

    private void Start()
    {
        StartCoroutine(LoadRoutine());
    }

    private IEnumerator LoadRoutine()
    {
        yield return null;

        string targetScene = SceneLoader.TargetSceneName;
        if (string.IsNullOrEmpty(targetScene))
        {
            Debug.LogError("[Loading] Target scene is not set.");
            yield break;
        }

        AsyncOperation op = SceneManager.LoadSceneAsync(targetScene);
        op.allowSceneActivation = false;

        float t = 0f;

        while (!op.isDone)
        {
            yield return null;
            t += Time.deltaTime;

            float target = (op.progress < 0.9f) ? op.progress : 1f;
            loadingBar.value = Mathf.Lerp(loadingBar.value, target, t);

            if (loadingBar.value >= target - 0.0001f)
                t = 0f;

            if (loadingBar.value >= 0.99f)
            {
                yield return new WaitForSeconds(1f);
                op.allowSceneActivation = true;
                yield break;
            }
        }
    }
}
