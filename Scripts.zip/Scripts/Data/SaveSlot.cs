using System;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SaveSlot : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TextMeshProUGUI slotNameText;
    [SerializeField] private TextMeshProUGUI levelText;
    [SerializeField] private TextMeshProUGUI dateText;
    [SerializeField] private TextMeshProUGUI playTimeText;
    [SerializeField] private TextMeshProUGUI emptyText;

    [Header("Buttons")]
    [SerializeField] private Button slotButton;
    [SerializeField] private Button deleteButton;

    [Header("Settings")]
    [SerializeField] private int slotIndex;
    [SerializeField] private string downloadSceneName = "DownLoad";

    private bool hasData;

    private void Awake()
    {
        slotButton.onClick.AddListener(OnClickSlot);
        deleteButton.onClick.AddListener(OnClickDelete);
    }

    private void Start()
    {
        RefreshSlot();
    }

    public void RefreshSlot()
    {
        if (!File.Exists(GetSavePath()))
        {
            SetEmptySlot();
            return;
        }

        SetFilledSlot();
        LoadSaveData();
    }

    private string GetSavePath()
    {
        return SaveManager.Instance.GetSavePath(slotIndex);
    }

    private void SetEmptySlot()
    {
        hasData = false;

        emptyText.gameObject.SetActive(true);
        levelText.gameObject.SetActive(false);
        dateText.gameObject.SetActive(false);
        playTimeText.gameObject.SetActive(false);
        slotNameText.gameObject.SetActive(false);
        deleteButton.gameObject.SetActive(false);
    }

    private void SetFilledSlot()
    {
        hasData = true;

        emptyText.gameObject.SetActive(false);
        levelText.gameObject.SetActive(true);
        dateText.gameObject.SetActive(true);
        playTimeText.gameObject.SetActive(true);
        slotNameText.gameObject.SetActive(true);
        deleteButton.gameObject.SetActive(true);
    }

    private void LoadSaveData()
    {
        string json = File.ReadAllText(GetSavePath());
        SaveData data = JsonUtility.FromJson<SaveData>(json);

        levelText.text = $"Lv. {data.level}";
        dateText.text = data.saveTime ?? "-";

        TimeSpan time = TimeSpan.FromSeconds(data.playTimeSeconds);
        playTimeText.text = time.ToString(@"hh\:mm\:ss");
    }

    private void OnClickSlot()
    {
        SaveManager.Instance.SelectSlot(slotIndex, loadOnMain: hasData);
        SceneManager.LoadScene(downloadSceneName);

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }

    private void OnClickDelete()
    {
        if (!hasData)
            return;

        SaveManager.Instance.DeleteSave(slotIndex);
        RefreshSlot();

        AudioManager.Instance?.PlaySfx(SfxType.ButtonClick);
    }
}
