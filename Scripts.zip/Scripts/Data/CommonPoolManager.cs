﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class CommonPoolManager : MonoBehaviour
{
    [System.Serializable]
    public class PoolData
    {
        public string key;
        public GameObject prefab;
        public int initialSize = 10;
        public int maxSize = 50;
    }

    [SerializeField] private List<PoolData> poolDataList;

    private readonly Dictionary<string, ObjectPool<GameObject>> pools = new();

    private void Awake()
    {
        BuildPools();
    }

    private void BuildPools()
    {
        pools.Clear();

        if (poolDataList == null)
        {
            Debug.LogError("[공용 풀] poolDataList가 비어 있습니다.");
            return;
        }

        foreach (var data in poolDataList)
        {
            if (data == null)
                continue;

            if (string.IsNullOrWhiteSpace(data.key))
            {
                Debug.LogError("[공용 풀] 풀 키가 비어 있습니다.");
                continue;
            }

            if (data.prefab == null)
            {
                Debug.LogError($"[공용 풀] 프리팹이 비어 있습니다: {data.key}");
                continue;
            }

            if (pools.ContainsKey(data.key))
            {
                Debug.LogError($"[공용 풀] 중복된 풀 키입니다: {data.key}");
                continue;
            }

            var pool = new ObjectPool<GameObject>(
                () => CreateObject(data.prefab),
                obj => obj.SetActive(true),
                obj => obj.SetActive(false),
                Destroy,
                false,
                Mathf.Max(0, data.initialSize),
                Mathf.Max(1, data.maxSize)
            );

            for (int i = 0; i < data.initialSize; i++)
            {
                var obj = Instantiate(data.prefab, transform);
                obj.SetActive(false);
                pool.Release(obj);
            }

            pools.Add(data.key, pool);
        }
    }

    private GameObject CreateObject(GameObject prefab)
    {
        var obj = Instantiate(prefab, transform);
        obj.SetActive(false);
        return obj;
    }
    public bool HasKey(string key)
    {
        if (string.IsNullOrEmpty(key))
            return false;

        return pools.ContainsKey(key);
    }

    public GameObject GetObject(string key, Vector3 position, Quaternion rotation)
    {
        if (!pools.TryGetValue(key, out var pool))
        {
            Debug.LogError($"[공용 풀] 풀을 찾을 수 없습니다: {key}");
            return null;
        }

        var obj = pool.Get();
        obj.transform.SetParent(null);
        obj.transform.SetPositionAndRotation(position, rotation);
        return obj;
    }

    public void ReleaseObject(string key, GameObject obj)
    {
        if (obj == null)
            return;

        if (!pools.TryGetValue(key, out var pool))
        {
            Destroy(obj);
            return;
        }

        obj.transform.SetParent(transform);
        pool.Release(obj);
    }
}
