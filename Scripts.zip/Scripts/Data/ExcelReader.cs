﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using Cysharp.Threading.Tasks;

public enum ItemKind
{
    Consumable,
    Weapon,
    Material,
    Etc
}

public class ExcelReader : MonoBehaviour
{
    public static ExcelReader Instance { get; private set; }

    public Dictionary<int, SkillData> dicSkill = new();
    public Dictionary<string, Item> dicItem = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public async UniTask LoadAll()
    {
        await LoadSkillCSV_Addressables("Data/Skill_info");
        await LoadItemCSV_Addressables("Data/Item_info");
    }

    public async UniTask LoadSkillCSV_Addressables(string addressKey)
    {
        dicSkill.Clear();

        var handle = Addressables.LoadAssetAsync<TextAsset>(addressKey);
        TextAsset csvData = await handle.Task;

        if (handle.Status != AsyncOperationStatus.Succeeded || csvData == null)
        {
            Debug.LogError($"[엑셀 로더] 스킬 CSV 로드 실패: {addressKey}");
            Addressables.Release(handle);
            return;
        }

        ParseSkillCSV(csvData.text);
        Addressables.Release(handle);
    }

    public async UniTask LoadItemCSV_Addressables(string addressKey)
    {
        dicItem.Clear();

        var handle = Addressables.LoadAssetAsync<TextAsset>(addressKey);
        TextAsset csvData = await handle.Task;

        if (handle.Status != AsyncOperationStatus.Succeeded || csvData == null)
        {
            Debug.LogError($"[엑셀 로더] 아이템 CSV 로드 실패: {addressKey}");
            Addressables.Release(handle);
            return;
        }

        ParseItemCSV(csvData.text);
        Addressables.Release(handle);
    }

    private void ParseSkillCSV(string text)
    {
        string[] lines = text.Split('\n');

        for (int i = 1; i < lines.Length; i++)
        {
            string line = lines[i].Trim();
            if (string.IsNullOrWhiteSpace(line)) continue;

            var v = line.Split(',');
            if (v.Length < 6) continue;
            if (!int.TryParse(v[0], out int code)) continue;

            SkillData data = new SkillData
            {
                Code = code,
                Name = v[1],
                Key = v[2],
                Explain = v[3],
                Damage = float.TryParse(v[4], out var dmg) ? dmg : 100f,
                CoolTime = float.TryParse(v[5], out var ct) ? ct : 0f,
                MpCost = v.Length > 6 && float.TryParse(v[6], out var mp) ? mp : 0f,
                RequiredLevel = v.Length > 7 && int.TryParse(v[7], out var lv) ? lv : 1
            };

            dicSkill[data.Code] = data;
        }
    }

    private void ParseItemCSV(string text)
    {
        string[] lines = text.Split('\n');

        for (int i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(lines[i])) continue;
            var v = lines[i].Trim().Split(',');
            if (v.Length < 13) continue;

            ItemKind type = ItemKind.Etc;
            System.Enum.TryParse(v[4], true, out type);

            Item item = type switch
            {
                ItemKind.Consumable => new ConsumableItem
                {
                    HealHP = ParseIntSafe(v, 6),
                    HealMP = ParseIntSafe(v, 7)
                },
                ItemKind.Weapon => new WeaponItem
                {
                    AttackPower = ParseIntSafe(v, 8),
                    DefensePower = ParseIntSafe(v, 9),
                    HP = ParseIntSafe(v, 10),
                    MP = ParseIntSafe(v, 11)
                },
                _ => new Item()
            };

            EquipSlot equipSlot = EquipSlot.Etc;
            System.Enum.TryParse(v[12], true, out equipSlot);

            item.Code = v[0];
            item.Name = v[1];
            item.Key = v[2];
            item.Explain = v[3];
            item.Type = type;
            item.Price = int.TryParse(v[5], out var p) ? p : 0;
            item.EquipSlot = equipSlot;

            dicItem.TryAdd(item.Code, item);
        }
    }

    private int ParseIntSafe(string[] v, int idx, int def = 0)
    {
        if (idx < 0 || idx >= v.Length) return def;
        return int.TryParse(v[idx], out var val) ? val : def;
    }
}
