﻿using System.Collections.Generic;

public static class DataLabels
{
    public static readonly IReadOnlyList<string> All = new[]
    {
        "Data_Dialogue",
        "Data_Reward",
        "Data_RewardItem",
        "Data_Monster_info",
        "Data_NPC_info",
        "Data_Skill_info",
        "Data_Item_info",
        "Data_Quest",
        "Data_QuestObjectives",
    };
}
