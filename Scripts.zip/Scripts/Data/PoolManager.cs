﻿using UnityEngine;

public class PoolManager : MonoBehaviour
{
    public static PoolManager Instance;

    [SerializeField] private CommonPoolManager commonPool;
    private MonsterPoolManager monsterPool;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        if (commonPool == null)
            commonPool = GetComponentInChildren<CommonPoolManager>(true);

        if (commonPool == null)
            Debug.LogError("[풀 매니저] CommonPoolManager가 연결되지 않았습니다.");
    }

    public void RegisterMonsterPool(MonsterPoolManager pool)
    {
        monsterPool = pool;
    }

    public void UnregisterMonsterPool(MonsterPoolManager pool)
    {
        if (monsterPool == pool)
            monsterPool = null;
    }

    public GameObject GetObject(string key, Vector3 position, Quaternion rotation)
    {
        if (commonPool != null && commonPool.HasKey(key))
            return commonPool.GetObject(key, position, rotation);

        if (monsterPool != null && monsterPool.HasKey(key))
            return monsterPool.GetObject(key, position, rotation);

        Debug.LogError($"[풀 매니저] 요청한 키를 찾을 수 없습니다 : {key}");
        return null;
    }

    public void ReleaseObject(string key, GameObject obj)
    {
        if (obj == null)
            return;

        if (commonPool != null && commonPool.HasKey(key))
        {
            commonPool.ReleaseObject(key, obj);
            return;
        }

        if (monsterPool != null && monsterPool.HasKey(key))
        {
            monsterPool.ReleaseObject(key, obj);
            return;
        }

        Destroy(obj);
    }
}
