﻿using UnityEngine;
using Cysharp.Threading.Tasks;

public class GameDataManager : MonoBehaviour
{
    public static GameDataManager Instance;

    [SerializeField] private string monsterAddress = "Data/Monster_info";
    [SerializeField] private string skillAddress = "Data/Skill_info";
    [SerializeField] private string itemAddress = "Data/Item_info";

    [SerializeField] private QuestDatabase questDatabase;
    [SerializeField] private DialogueDatabase dialogueDatabase;
    [SerializeField] private RewardDatabase rewardDatabase;
    [SerializeField] private LoadNameManager loadNameManager;

    private bool initialized;
    public bool IsReady { get; private set; } = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        Bootstrap().Forget();
    }

    private async UniTaskVoid Bootstrap()
    {
        if (IsReady) return;

        IsReady = false;

        try
        {
            await InitializeAllData();

            if (questDatabase != null) await questDatabase.LoadAll();
            if (dialogueDatabase != null) await dialogueDatabase.LoadAll();
            if (rewardDatabase != null) await rewardDatabase.LoadAll();
            if (loadNameManager != null) await loadNameManager.LoadAll();

            IsReady = true;
            Debug.Log("[GameDataManager] 모든 데이터 로드 완료(IsReady=true)");
        }
        catch (System.Exception e)
        {
            Debug.LogError($"[GameDataManager] Bootstrap 실패\n{e}");
            IsReady = false;
        }
    }

    public async UniTask InitializeAllData()
    {
        if (initialized) return;
        initialized = true;

        var monsters = await MonsterCSVLoader.LoadAddressablesAsync(monsterAddress);
        MonsterDatabase.Initialize(monsters);

        if (ExcelReader.Instance != null)
        {
            await ExcelReader.Instance.LoadSkillCSV_Addressables(skillAddress);
            await ExcelReader.Instance.LoadItemCSV_Addressables(itemAddress);
        }
        else
        {
            Debug.LogError("[GameDataManager] ExcelReader.Instance 가 null 입니다. 씬/프리팹 세팅 확인!");
        }
    }
}
